package com.huawei.bigdata.sorter;

import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.parquet.avro.AvroParquetWriter;
import org.apache.parquet.hadoop.ParquetWriter;
import org.apache.parquet.hadoop.metadata.CompressionCodecName;
import org.junit.jupiter.api.*;

import java.io.IOException;
import java.nio.file.Files;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

/**
 * ExternalSorter单元测试
 */
class ExternalSorterTest {

    private static final String TEST_SCHEMA_JSON = """
            {
              "type": "record",
              "name": "TestRecord",
              "namespace": "com.huawei.test",
              "fields": [
                {"name": "id", "type": "long"},
                {"name": "name", "type": "string"},
                {"name": "timestamp", "type": "long"},
                {"name": "value", "type": "double"}
              ]
            }
            """;

    private java.nio.file.Path tempDir;
    private java.nio.file.Path testParquetFile;
    private Schema schema;

    @BeforeEach
    void setUp() throws IOException {
        tempDir = Files.createTempDirectory("external-sorter-test");
        testParquetFile = tempDir.resolve("test-data.parquet");
        schema = new Schema.Parser().parse(TEST_SCHEMA_JSON);
    }

    @AfterEach
    void tearDown() throws IOException {
        // 清理临时文件
        if (tempDir != null && Files.exists(tempDir)) {
            Files.walk(tempDir)
                    .sorted(Comparator.reverseOrder())
                    .forEach(path -> {
                        try {
                            Files.delete(path);
                        } catch (IOException e) {
                            // ignore
                        }
                    });
        }
    }

    @Test
    @DisplayName("测试基本排序功能")
    void testBasicSort() throws IOException {
        // 创建测试数据
        createTestParquetFile(1000, false);

        ExternalSorterConfig config = ExternalSorterConfig.builder()
                .memoryLimit(64 * 1024 * 1024)  // 64MB
                .sortBufferSize(16 * 1024 * 1024)  // 16MB
                .addSpillDirectory(tempDir.resolve("spill"))
                .parallelism(2)
                .build();

        try (ExternalSorter sorter = new ExternalSorter(config)) {
            Iterator<GenericRecord> result = sorter.sort(
                    testParquetFile.toString(),
                    Arrays.asList("id"),
                    MergeFunction.keepLatest()
            );

            // 验证结果是有序的
            long prevId = Long.MIN_VALUE;
            int count = 0;
            while (result.hasNext()) {
                GenericRecord record = result.next();
                long id = (Long) record.get("id");
                assertTrue(id >= prevId, "Records should be sorted by id");
                prevId = id;
                count++;
            }

            assertEquals(1000, count, "Should have 1000 records");
        }
    }

    @Test
    @DisplayName("测试去重功能")
    void testDeduplication() throws IOException {
        // 创建带有重复数据的测试文件
        createTestParquetFile(1000, true);

        ExternalSorterConfig config = ExternalSorterConfig.builder()
                .memoryLimit(64 * 1024 * 1024)
                .addSpillDirectory(tempDir.resolve("spill"))
                .parallelism(2)
                .build();

        try (ExternalSorter sorter = new ExternalSorter(config)) {
            Iterator<GenericRecord> result = sorter.sort(
                    testParquetFile.toString(),
                    Arrays.asList("id"),
                    MergeFunction.keepLatest()
            );

            // 收集所有ID
            Set<Long> ids = new HashSet<>();
            while (result.hasNext()) {
                GenericRecord record = result.next();
                long id = (Long) record.get("id");
                assertFalse(ids.contains(id), "Should not have duplicate ids");
                ids.add(id);
            }

            // 去重后应该只有500条记录（原始1000条，每个ID重复2次）
            assertEquals(500, ids.size(), "Should have 500 unique records after deduplication");
        }
    }

    @Test
    @DisplayName("测试多列排序")
    void testMultiColumnSort() throws IOException {
        createTestParquetFile(500, false);

        ExternalSorterConfig config = ExternalSorterConfig.builder()
                .memoryLimit(64 * 1024 * 1024)
                .addSpillDirectory(tempDir.resolve("spill"))
                .build();

        try (ExternalSorter sorter = new ExternalSorter(config)) {
            Iterator<GenericRecord> result = sorter.sort(
                    testParquetFile.toString(),
                    Arrays.asList("name", "timestamp"),
                    MergeFunction.keepLatest()
            );

            String prevName = "";
            long prevTimestamp = Long.MIN_VALUE;
            while (result.hasNext()) {
                GenericRecord record = result.next();
                String name = record.get("name").toString();
                long timestamp = (Long) record.get("timestamp");

                int nameCompare = name.compareTo(prevName);
                if (nameCompare == 0) {
                    assertTrue(timestamp >= prevTimestamp, 
                            "Records with same name should be sorted by timestamp");
                }
                prevName = name;
                prevTimestamp = nameCompare == 0 ? timestamp : Long.MIN_VALUE;
            }
        }
    }

    @Test
    @DisplayName("测试自定义合并函数")
    void testCustomMergeFunction() throws IOException {
        createTestParquetFile(500, true);

        ExternalSorterConfig config = ExternalSorterConfig.builder()
                .memoryLimit(64 * 1024 * 1024)
                .addSpillDirectory(tempDir.resolve("spill"))
                .build();

        // 使用基于timestamp字段的合并函数，保留timestamp较大的记录
        MergeFunction<GenericRecord> mergeByTimestamp = 
                MergeFunction.byField("timestamp", true);

        try (ExternalSorter sorter = new ExternalSorter(config)) {
            Iterator<GenericRecord> result = sorter.sort(
                    testParquetFile.toString(),
                    Arrays.asList("id"),
                    mergeByTimestamp
            );

            int count = 0;
            while (result.hasNext()) {
                result.next();
                count++;
            }

            assertTrue(count > 0, "Should have records");
        }
    }

    @Test
    @DisplayName("测试空文件处理")
    void testEmptyFile() throws IOException {
        // 创建空的Parquet文件
        createEmptyParquetFile();

        ExternalSorterConfig config = ExternalSorterConfig.builder()
                .memoryLimit(64 * 1024 * 1024)
                .addSpillDirectory(tempDir.resolve("spill"))
                .build();

        try (ExternalSorter sorter = new ExternalSorter(config)) {
            assertThrows(IOException.class, () -> {
                sorter.sort(
                        testParquetFile.toString(),
                        Arrays.asList("id"),
                        MergeFunction.keepLatest()
                );
            }, "Should throw exception for empty file");
        }
    }

    @Test
    @DisplayName("测试无效排序键")
    void testInvalidSortKey() throws IOException {
        createTestParquetFile(100, false);

        ExternalSorterConfig config = ExternalSorterConfig.builder()
                .memoryLimit(64 * 1024 * 1024)
                .addSpillDirectory(tempDir.resolve("spill"))
                .build();

        try (ExternalSorter sorter = new ExternalSorter(config)) {
            assertThrows(IllegalArgumentException.class, () -> {
                sorter.sort(
                        testParquetFile.toString(),
                        Arrays.asList("nonexistent_column"),
                        MergeFunction.keepLatest()
                );
            }, "Should throw exception for invalid sort key");
        }
    }

    @Test
    @DisplayName("测试RecordComparator")
    void testRecordComparator() {
        RecordComparator comparator = new RecordComparator(
                Arrays.asList("id", "name"),
                Arrays.asList(true, false)  // id ASC, name DESC
        );

        GenericRecord r1 = new GenericData.Record(schema);
        r1.put("id", 1L);
        r1.put("name", "Alice");
        r1.put("timestamp", 100L);
        r1.put("value", 1.0);

        GenericRecord r2 = new GenericData.Record(schema);
        r2.put("id", 1L);
        r2.put("name", "Bob");
        r2.put("timestamp", 200L);
        r2.put("value", 2.0);

        GenericRecord r3 = new GenericData.Record(schema);
        r3.put("id", 2L);
        r3.put("name", "Alice");
        r3.put("timestamp", 300L);
        r3.put("value", 3.0);

        // r1 vs r2: same id, name comparison (DESC)
        assertTrue(comparator.compare(r1, r2) > 0, "Bob should come before Alice (DESC)");

        // r1 vs r3: different id (ASC)
        assertTrue(comparator.compare(r1, r3) < 0, "id 1 should come before id 2 (ASC)");

        // keysEqual test
        assertTrue(comparator.keysEqual(r1, r1));
        assertFalse(comparator.keysEqual(r1, r2));
    }

    @Test
    @DisplayName("测试MemoryTracker")
    void testMemoryTracker() throws InterruptedException {
        MemoryTracker tracker = new MemoryTracker(1024 * 1024);  // 1MB

        // 测试基本申请和释放
        assertTrue(tracker.tryAcquire(512 * 1024));  // 512KB
        assertEquals(512 * 1024, tracker.getUsedMemory());

        assertTrue(tracker.tryAcquire(256 * 1024));  // 256KB
        assertEquals(768 * 1024, tracker.getUsedMemory());

        // 超过限制的申请应该失败
        assertFalse(tracker.tryAcquire(512 * 1024));

        // 释放内存
        tracker.release(512 * 1024);
        assertEquals(256 * 1024, tracker.getUsedMemory());

        // 现在应该可以申请更多
        assertTrue(tracker.tryAcquire(512 * 1024));
    }

    /**
     * 创建测试Parquet文件
     */
    private void createTestParquetFile(int recordCount, boolean withDuplicates) throws IOException {
        Configuration conf = new Configuration();
        Path parquetPath = new Path(testParquetFile.toString());

        try (ParquetWriter<GenericRecord> writer = AvroParquetWriter
                .<GenericRecord>builder(parquetPath)
                .withSchema(schema)
                .withConf(conf)
                .withCompressionCodec(CompressionCodecName.SNAPPY)
                .build()) {

            Random random = new Random(42);
            String[] names = {"Alice", "Bob", "Charlie", "David", "Eve"};

            for (int i = 0; i < recordCount; i++) {
                GenericRecord record = new GenericData.Record(schema);
                // 如果withDuplicates，则ID范围减半以产生重复
                long id = withDuplicates ? i / 2 : i;
                record.put("id", id);
                record.put("name", names[random.nextInt(names.length)]);
                record.put("timestamp", System.currentTimeMillis() + i);
                record.put("value", random.nextDouble() * 100);
                writer.write(record);
            }
        }
    }

    /**
     * 创建空的Parquet文件（实际上创建一个只有一条记录的文件用于获取schema，然后重新创建空文件）
     */
    private void createEmptyParquetFile() throws IOException {
        // Parquet不能创建真正的空文件，所以这里用一个空的迭代器来模拟
        // 实际测试时会抛出异常，因为无法从空文件读取schema
        Configuration conf = new Configuration();
        Path parquetPath = new Path(testParquetFile.toString());

        // 创建一个最小的文件
        try (ParquetWriter<GenericRecord> writer = AvroParquetWriter
                .<GenericRecord>builder(parquetPath)
                .withSchema(schema)
                .withConf(conf)
                .build()) {
            // 不写入任何记录
        }
    }
}
