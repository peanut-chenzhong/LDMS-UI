package com.huawei.bigdata.sorter;

import org.apache.avro.generic.GenericRecord;

/**
 * 合并函数接口
 * 
 * 用于在外部排序过程中对具有相同排序键的记录进行合并去重。
 * 实现此接口可以自定义合并逻辑。
 *
 * @param <T> 记录类型，必须是GenericRecord的子类型
 */
@FunctionalInterface
public interface MergeFunction<T extends GenericRecord> {

    /**
     * 合并两条具有相同排序键的记录
     * 
     * 当外部排序过程中遇到具有相同排序键的记录时，会调用此方法进行合并。
     * 实现应该返回合并后的记录，该记录将替代原有的两条记录。
     *
     * @param existing 已存在的记录（先出现的记录）
     * @param incoming 新到来的记录（后出现的记录）
     * @return 合并后的记录
     */
    T merge(T existing, T incoming);

    /**
     * 创建一个保留最新记录的合并函数
     * 
     * @param <T> 记录类型
     * @return 保留最新记录的合并函数
     */
    static <T extends GenericRecord> MergeFunction<T> keepLatest() {
        return (existing, incoming) -> incoming;
    }

    /**
     * 创建一个保留最早记录的合并函数
     * 
     * @param <T> 记录类型
     * @return 保留最早记录的合并函数
     */
    static <T extends GenericRecord> MergeFunction<T> keepFirst() {
        return (existing, incoming) -> existing;
    }

    /**
     * 创建一个基于字段选择的合并函数
     * 根据指定字段的值选择保留哪条记录
     *
     * @param <T> 记录类型
     * @param fieldName 用于比较的字段名
     * @param keepLarger 是否保留较大值的记录
     * @return 基于字段选择的合并函数
     */
    static <T extends GenericRecord> MergeFunction<T> byField(String fieldName, boolean keepLarger) {
        return (existing, incoming) -> {
            Object existingValue = existing.get(fieldName);
            Object incomingValue = incoming.get(fieldName);
            
            if (existingValue == null && incomingValue == null) {
                return incoming;
            }
            if (existingValue == null) {
                return keepLarger ? incoming : existing;
            }
            if (incomingValue == null) {
                return keepLarger ? existing : incoming;
            }
            
            @SuppressWarnings("unchecked")
            Comparable<Object> existingComparable = (Comparable<Object>) existingValue;
            int cmp = existingComparable.compareTo(incomingValue);
            
            if (keepLarger) {
                return cmp >= 0 ? existing : incoming;
            } else {
                return cmp <= 0 ? existing : incoming;
            }
        };
    }
}
