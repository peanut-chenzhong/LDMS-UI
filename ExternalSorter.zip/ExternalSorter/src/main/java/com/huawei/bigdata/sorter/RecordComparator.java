package com.huawei.bigdata.sorter;

import org.apache.avro.generic.GenericRecord;
import org.apache.avro.util.Utf8;

import java.nio.ByteBuffer;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

/**
 * Avro记录比较器
 * 
 * 根据指定的排序键对GenericRecord进行比较。
 * 支持多列排序和升序/降序配置。
 */
public class RecordComparator implements Comparator<GenericRecord> {

    private final List<String> sortKeys;
    private final List<Boolean> ascending;

    /**
     * 创建记录比较器（全部升序）
     *
     * @param sortKeys 排序键列表
     */
    public RecordComparator(List<String> sortKeys) {
        this(sortKeys, null);
    }

    /**
     * 创建记录比较器
     *
     * @param sortKeys 排序键列表
     * @param ascending 升序/降序配置列表，null表示全部升序
     */
    public RecordComparator(List<String> sortKeys, List<Boolean> ascending) {
        if (sortKeys == null || sortKeys.isEmpty()) {
            throw new IllegalArgumentException("Sort keys cannot be null or empty");
        }
        this.sortKeys = sortKeys;
        if (ascending == null) {
            this.ascending = sortKeys.stream().map(k -> Boolean.TRUE).toList();
        } else {
            if (ascending.size() != sortKeys.size()) {
                throw new IllegalArgumentException(
                        "Ascending list size must match sort keys size");
            }
            this.ascending = ascending;
        }
    }

    @Override
    public int compare(GenericRecord r1, GenericRecord r2) {
        if (r1 == r2) {
            return 0;
        }
        if (r1 == null) {
            return -1;
        }
        if (r2 == null) {
            return 1;
        }

        for (int i = 0; i < sortKeys.size(); i++) {
            String key = sortKeys.get(i);
            Object v1 = r1.get(key);
            Object v2 = r2.get(key);
            
            int cmp = compareValues(v1, v2);
            if (cmp != 0) {
                return ascending.get(i) ? cmp : -cmp;
            }
        }
        
        return 0;
    }

    /**
     * 比较两个值
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    private int compareValues(Object v1, Object v2) {
        // 处理null
        if (v1 == null && v2 == null) {
            return 0;
        }
        if (v1 == null) {
            return -1;
        }
        if (v2 == null) {
            return 1;
        }

        // 处理Utf8字符串
        if (v1 instanceof Utf8 || v2 instanceof Utf8) {
            String s1 = v1.toString();
            String s2 = v2.toString();
            return s1.compareTo(s2);
        }

        // 处理ByteBuffer
        if (v1 instanceof ByteBuffer && v2 instanceof ByteBuffer) {
            return compareByteBuffers((ByteBuffer) v1, (ByteBuffer) v2);
        }

        // 处理byte数组
        if (v1 instanceof byte[] && v2 instanceof byte[]) {
            return compareByteArrays((byte[]) v1, (byte[]) v2);
        }

        // 处理Comparable类型
        if (v1 instanceof Comparable && v2.getClass().isAssignableFrom(v1.getClass())) {
            return ((Comparable) v1).compareTo(v2);
        }

        // 降级到toString比较
        return v1.toString().compareTo(v2.toString());
    }

    /**
     * 比较ByteBuffer
     */
    private int compareByteBuffers(ByteBuffer b1, ByteBuffer b2) {
        int len1 = b1.remaining();
        int len2 = b2.remaining();
        int minLen = Math.min(len1, len2);
        
        for (int i = 0; i < minLen; i++) {
            int cmp = Byte.compare(b1.get(b1.position() + i), b2.get(b2.position() + i));
            if (cmp != 0) {
                return cmp;
            }
        }
        
        return Integer.compare(len1, len2);
    }

    /**
     * 比较byte数组
     */
    private int compareByteArrays(byte[] b1, byte[] b2) {
        int minLen = Math.min(b1.length, b2.length);
        
        for (int i = 0; i < minLen; i++) {
            int cmp = Byte.compare(b1[i], b2[i]);
            if (cmp != 0) {
                return cmp;
            }
        }
        
        return Integer.compare(b1.length, b2.length);
    }

    /**
     * 检查两条记录是否具有相同的排序键
     *
     * @param r1 记录1
     * @param r2 记录2
     * @return 是否相同
     */
    public boolean keysEqual(GenericRecord r1, GenericRecord r2) {
        if (r1 == r2) {
            return true;
        }
        if (r1 == null || r2 == null) {
            return false;
        }
        
        for (String key : sortKeys) {
            Object v1 = r1.get(key);
            Object v2 = r2.get(key);
            if (!Objects.equals(v1, v2)) {
                // 特殊处理Utf8
                if (v1 instanceof Utf8 || v2 instanceof Utf8) {
                    if (v1 != null && v2 != null && v1.toString().equals(v2.toString())) {
                        continue;
                    }
                }
                return false;
            }
        }
        
        return true;
    }

    /**
     * 获取排序键列表
     */
    public List<String> getSortKeys() {
        return sortKeys;
    }

    /**
     * 获取升序配置列表
     */
    public List<Boolean> getAscending() {
        return ascending;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("RecordComparator{keys=[");
        for (int i = 0; i < sortKeys.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(sortKeys.get(i));
            sb.append(ascending.get(i) ? " ASC" : " DESC");
        }
        sb.append("]}");
        return sb.toString();
    }
}
