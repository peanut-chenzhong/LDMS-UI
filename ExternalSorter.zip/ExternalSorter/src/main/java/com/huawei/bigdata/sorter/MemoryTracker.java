package com.huawei.bigdata.sorter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

/**
 * 内存追踪器
 * 
 * 用于追踪和控制外部排序过程中的内存使用，防止OOM。
 * 提供内存申请、释放和等待机制。
 */
public class MemoryTracker {

    private static final Logger LOG = LoggerFactory.getLogger(MemoryTracker.class);

    /** 内存限制（字节） */
    private final long memoryLimit;
    
    /** 当前已使用内存（字节） */
    private final AtomicLong usedMemory;
    
    /** 峰值内存使用（字节） */
    private final AtomicLong peakMemory;
    
    /** 内存申请总量（字节） */
    private final AtomicLong totalAllocated;
    
    /** 内存释放总量（字节） */
    private final AtomicLong totalFreed;
    
    /** 用于等待内存释放的锁 */
    private final ReentrantLock lock;
    
    /** 内存释放条件 */
    private final Condition memoryAvailable;
    
    /** 溢写触发阈值（默认80%） */
    private final double spillThreshold;

    /**
     * 创建内存追踪器
     *
     * @param memoryLimit 内存限制（字节）
     */
    public MemoryTracker(long memoryLimit) {
        this(memoryLimit, 0.8);
    }

    /**
     * 创建内存追踪器
     *
     * @param memoryLimit 内存限制（字节）
     * @param spillThreshold 溢写触发阈值（0-1之间）
     */
    public MemoryTracker(long memoryLimit, double spillThreshold) {
        if (memoryLimit <= 0) {
            throw new IllegalArgumentException("Memory limit must be positive");
        }
        if (spillThreshold <= 0 || spillThreshold > 1) {
            throw new IllegalArgumentException("Spill threshold must be between 0 and 1");
        }
        
        this.memoryLimit = memoryLimit;
        this.spillThreshold = spillThreshold;
        this.usedMemory = new AtomicLong(0);
        this.peakMemory = new AtomicLong(0);
        this.totalAllocated = new AtomicLong(0);
        this.totalFreed = new AtomicLong(0);
        this.lock = new ReentrantLock();
        this.memoryAvailable = lock.newCondition();
        
        LOG.info("MemoryTracker initialized with limit: {} MB, spill threshold: {}%",
                memoryLimit / (1024 * 1024), spillThreshold * 100);
    }

    /**
     * 尝试申请内存
     * 如果内存不足，不会阻塞，直接返回false
     *
     * @param bytes 要申请的字节数
     * @return 是否申请成功
     */
    public boolean tryAcquire(long bytes) {
        if (bytes <= 0) {
            return true;
        }
        
        long current = usedMemory.get();
        while (current + bytes <= memoryLimit) {
            if (usedMemory.compareAndSet(current, current + bytes)) {
                totalAllocated.addAndGet(bytes);
                updatePeakMemory(current + bytes);
                LOG.trace("Memory acquired: {} bytes, total used: {} MB", 
                        bytes, (current + bytes) / (1024.0 * 1024));
                return true;
            }
            current = usedMemory.get();
        }
        
        LOG.debug("Memory acquisition failed: requested {} bytes, available {} bytes",
                bytes, memoryLimit - current);
        return false;
    }

    /**
     * 申请内存，如果内存不足会阻塞等待
     *
     * @param bytes 要申请的字节数
     * @param timeoutMs 超时时间（毫秒），0表示无限等待
     * @return 是否申请成功
     * @throws InterruptedException 如果等待被中断
     */
    public boolean acquire(long bytes, long timeoutMs) throws InterruptedException {
        if (bytes <= 0) {
            return true;
        }
        
        // 首先尝试无锁申请
        if (tryAcquire(bytes)) {
            return true;
        }
        
        // 需要等待内存释放
        lock.lock();
        try {
            long remainingTime = timeoutMs;
            long startTime = System.currentTimeMillis();
            
            while (!tryAcquire(bytes)) {
                if (timeoutMs == 0) {
                    memoryAvailable.await();
                } else {
                    if (remainingTime <= 0) {
                        LOG.warn("Memory acquisition timed out after {} ms", timeoutMs);
                        return false;
                    }
                    memoryAvailable.await(remainingTime, java.util.concurrent.TimeUnit.MILLISECONDS);
                    remainingTime = timeoutMs - (System.currentTimeMillis() - startTime);
                }
            }
            return true;
        } finally {
            lock.unlock();
        }
    }

    /**
     * 释放内存
     *
     * @param bytes 要释放的字节数
     */
    public void release(long bytes) {
        if (bytes <= 0) {
            return;
        }
        
        long newValue = usedMemory.addAndGet(-bytes);
        totalFreed.addAndGet(bytes);
        
        if (newValue < 0) {
            LOG.error("Memory accounting error: released more than acquired, adjusting to 0");
            usedMemory.set(0);
        }
        
        LOG.trace("Memory released: {} bytes, total used: {} MB", 
                bytes, Math.max(0, newValue) / (1024.0 * 1024));
        
        // 通知等待的线程
        lock.lock();
        try {
            memoryAvailable.signalAll();
        } finally {
            lock.unlock();
        }
    }

    /**
     * 更新峰值内存
     */
    private void updatePeakMemory(long currentUsed) {
        long peak = peakMemory.get();
        while (currentUsed > peak) {
            if (peakMemory.compareAndSet(peak, currentUsed)) {
                break;
            }
            peak = peakMemory.get();
        }
    }

    /**
     * 检查是否需要触发溢写
     *
     * @return 是否需要溢写
     */
    public boolean shouldSpill() {
        double usage = (double) usedMemory.get() / memoryLimit;
        boolean shouldSpill = usage >= spillThreshold;
        if (shouldSpill) {
            LOG.debug("Spill triggered: memory usage at {:.1f}% (threshold: {:.1f}%)",
                    usage * 100, spillThreshold * 100);
        }
        return shouldSpill;
    }

    /**
     * 获取当前内存使用量（字节）
     */
    public long getUsedMemory() {
        return usedMemory.get();
    }

    /**
     * 获取内存限制（字节）
     */
    public long getMemoryLimit() {
        return memoryLimit;
    }

    /**
     * 获取峰值内存使用（字节）
     */
    public long getPeakMemory() {
        return peakMemory.get();
    }

    /**
     * 获取可用内存（字节）
     */
    public long getAvailableMemory() {
        return Math.max(0, memoryLimit - usedMemory.get());
    }

    /**
     * 获取内存使用率（0-1之间）
     */
    public double getMemoryUsageRatio() {
        return (double) usedMemory.get() / memoryLimit;
    }

    /**
     * 估算记录的内存大小
     * 这是一个粗略估算，实际大小可能因序列化方式而异
     *
     * @param record Avro记录
     * @return 估算的字节数
     */
    public static long estimateRecordSize(org.apache.avro.generic.GenericRecord record) {
        if (record == null) {
            return 0;
        }
        
        // 基础对象开销
        long size = 16; // 对象头
        
        org.apache.avro.Schema schema = record.getSchema();
        for (org.apache.avro.Schema.Field field : schema.getFields()) {
            Object value = record.get(field.pos());
            size += estimateValueSize(value);
        }
        
        return size;
    }

    /**
     * 估算值的内存大小
     */
    private static long estimateValueSize(Object value) {
        if (value == null) {
            return 0;
        }
        
        if (value instanceof String) {
            return 40 + ((String) value).length() * 2L;
        } else if (value instanceof byte[]) {
            return 16 + ((byte[]) value).length;
        } else if (value instanceof Long || value instanceof Double) {
            return 24;
        } else if (value instanceof Integer || value instanceof Float) {
            return 16;
        } else if (value instanceof Boolean) {
            return 16;
        } else if (value instanceof java.util.List) {
            long size = 40;
            for (Object item : (java.util.List<?>) value) {
                size += estimateValueSize(item);
            }
            return size;
        } else if (value instanceof java.util.Map) {
            long size = 48;
            for (java.util.Map.Entry<?, ?> entry : ((java.util.Map<?, ?>) value).entrySet()) {
                size += estimateValueSize(entry.getKey());
                size += estimateValueSize(entry.getValue());
            }
            return size;
        } else if (value instanceof org.apache.avro.generic.GenericRecord) {
            return estimateRecordSize((org.apache.avro.generic.GenericRecord) value);
        } else {
            return 32; // 默认估算
        }
    }

    /**
     * 获取内存统计信息
     */
    public String getStats() {
        return String.format(
                "MemoryTracker Stats:\n" +
                "  Limit: %.2f MB\n" +
                "  Used: %.2f MB (%.1f%%)\n" +
                "  Peak: %.2f MB\n" +
                "  Total Allocated: %.2f MB\n" +
                "  Total Freed: %.2f MB",
                memoryLimit / (1024.0 * 1024),
                usedMemory.get() / (1024.0 * 1024),
                getMemoryUsageRatio() * 100,
                peakMemory.get() / (1024.0 * 1024),
                totalAllocated.get() / (1024.0 * 1024),
                totalFreed.get() / (1024.0 * 1024)
        );
    }

    /**
     * 重置统计信息（不影响当前使用量）
     */
    public void resetStats() {
        peakMemory.set(usedMemory.get());
        totalAllocated.set(0);
        totalFreed.set(0);
        LOG.debug("Memory stats reset");
    }
}
