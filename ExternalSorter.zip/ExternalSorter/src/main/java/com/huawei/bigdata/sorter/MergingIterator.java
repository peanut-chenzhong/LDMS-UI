package com.huawei.bigdata.sorter;

import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 合并迭代器
 * 
 * 将多个已排序的输入流合并为一个有序的输出流。
 * 使用小顶堆实现高效的K路归并排序。
 * 支持按排序键去重和自定义合并逻辑。
 */
public class MergingIterator implements Iterator<GenericRecord>, AutoCloseable {

    private static final Logger LOG = LoggerFactory.getLogger(MergingIterator.class);

    private final List<SortedRunReader> readers;
    private final RecordComparator comparator;
    private final MergeFunction<GenericRecord> mergeFunction;
    private final Schema schema;
    private final PriorityQueue<HeapEntry> minHeap;
    private final AtomicLong recordsOutput;
    private final AtomicLong recordsMerged;
    private GenericRecord nextRecord;
    private volatile boolean closed;

    /**
     * 堆条目，包装记录及其来源
     */
    private static class HeapEntry {
        final GenericRecord record;
        final int sourceIndex;

        HeapEntry(GenericRecord record, int sourceIndex) {
            this.record = record;
            this.sourceIndex = sourceIndex;
        }
    }

    /**
     * 创建合并迭代器
     *
     * @param readers 排序段读取器列表
     * @param comparator 记录比较器
     * @param mergeFunction 合并函数
     * @param schema Avro Schema
     */
    public MergingIterator(List<SortedRunReader> readers, 
                           RecordComparator comparator,
                           MergeFunction<GenericRecord> mergeFunction,
                           Schema schema) {
        this.readers = new ArrayList<>(readers);
        this.comparator = comparator;
        this.mergeFunction = mergeFunction;
        this.schema = schema;
        this.recordsOutput = new AtomicLong(0);
        this.recordsMerged = new AtomicLong(0);
        this.closed = false;
        
        // 创建小顶堆
        this.minHeap = new PriorityQueue<>(
                Math.max(1, readers.size()),
                (e1, e2) -> comparator.compare(e1.record, e2.record)
        );
        
        // 初始化堆
        initializeHeap();
        
        // 预取下一条记录
        this.nextRecord = fetchNext();
        
        LOG.debug("Created MergingIterator with {} input streams", readers.size());
    }

    /**
     * 初始化堆
     */
    private void initializeHeap() {
        for (int i = 0; i < readers.size(); i++) {
            SortedRunReader reader = readers.get(i);
            if (reader.hasNext()) {
                GenericRecord record = copyRecord(reader.next());
                minHeap.offer(new HeapEntry(record, i));
            }
        }
        LOG.debug("Heap initialized with {} entries", minHeap.size());
    }

    /**
     * 从堆中获取下一条记录（处理去重）
     */
    private GenericRecord fetchNext() {
        if (minHeap.isEmpty()) {
            return null;
        }
        
        // 取出最小元素
        HeapEntry minEntry = minHeap.poll();
        GenericRecord result = minEntry.record;
        
        // 从同一源补充记录
        refillFromSource(minEntry.sourceIndex);
        
        // 处理去重：合并所有具有相同键的记录
        while (!minHeap.isEmpty()) {
            HeapEntry nextEntry = minHeap.peek();
            if (comparator.keysEqual(result, nextEntry.record)) {
                // 相同键，需要合并
                minHeap.poll();
                result = mergeFunction.merge(result, nextEntry.record);
                recordsMerged.incrementAndGet();
                
                // 从该源补充记录
                refillFromSource(nextEntry.sourceIndex);
            } else {
                // 不同键，停止合并
                break;
            }
        }
        
        return result;
    }

    /**
     * 从指定源补充记录到堆中
     */
    private void refillFromSource(int sourceIndex) {
        SortedRunReader reader = readers.get(sourceIndex);
        if (reader.hasNext()) {
            GenericRecord record = copyRecord(reader.next());
            minHeap.offer(new HeapEntry(record, sourceIndex));
        }
    }

    /**
     * 复制记录（避免记录复用导致的问题）
     */
    private GenericRecord copyRecord(GenericRecord source) {
        if (source == null) {
            return null;
        }
        
        GenericRecord copy = new GenericData.Record(schema);
        for (Schema.Field field : schema.getFields()) {
            Object value = source.get(field.pos());
            copy.put(field.pos(), deepCopyValue(value));
        }
        return copy;
    }

    /**
     * 深拷贝值
     */
    @SuppressWarnings("unchecked")
    private Object deepCopyValue(Object value) {
        if (value == null) {
            return null;
        }
        
        if (value instanceof CharSequence) {
            return value.toString();
        } else if (value instanceof byte[]) {
            byte[] original = (byte[]) value;
            byte[] copy = new byte[original.length];
            System.arraycopy(original, 0, copy, 0, original.length);
            return copy;
        } else if (value instanceof List) {
            List<Object> original = (List<Object>) value;
            List<Object> copy = new ArrayList<>(original.size());
            for (Object item : original) {
                copy.add(deepCopyValue(item));
            }
            return copy;
        } else if (value instanceof Map) {
            Map<Object, Object> original = (Map<Object, Object>) value;
            Map<Object, Object> copy = new HashMap<>(original.size());
            for (Map.Entry<Object, Object> entry : original.entrySet()) {
                copy.put(deepCopyValue(entry.getKey()), deepCopyValue(entry.getValue()));
            }
            return copy;
        } else if (value instanceof GenericRecord) {
            return copyRecord((GenericRecord) value);
        } else {
            // 基本类型直接返回
            return value;
        }
    }

    @Override
    public boolean hasNext() {
        return nextRecord != null;
    }

    @Override
    public GenericRecord next() {
        if (nextRecord == null) {
            throw new NoSuchElementException("No more records");
        }
        
        GenericRecord result = nextRecord;
        nextRecord = fetchNext();
        recordsOutput.incrementAndGet();
        
        return result;
    }

    /**
     * 获取输出记录数
     */
    public long getRecordsOutput() {
        return recordsOutput.get();
    }

    /**
     * 获取合并的重复记录数
     */
    public long getRecordsMerged() {
        return recordsMerged.get();
    }

    /**
     * 获取输入流数量
     */
    public int getInputCount() {
        return readers.size();
    }

    /**
     * 获取堆中当前元素数量
     */
    public int getHeapSize() {
        return minHeap.size();
    }

    @Override
    public void close() throws IOException {
        if (!closed) {
            closed = true;
            
            List<Exception> exceptions = new ArrayList<>();
            for (SortedRunReader reader : readers) {
                try {
                    reader.close();
                } catch (IOException e) {
                    exceptions.add(e);
                }
            }
            
            minHeap.clear();
            
            LOG.info("Closed MergingIterator: {} records output, {} records merged (deduped)",
                    recordsOutput.get(), recordsMerged.get());
            
            if (!exceptions.isEmpty()) {
                IOException combined = new IOException("Failed to close some readers");
                exceptions.forEach(combined::addSuppressed);
                throw combined;
            }
        }
    }
}
