package com.huawei.bigdata.sorter;

import org.apache.avro.Schema;
import org.apache.avro.file.DataFileReader;
import org.apache.avro.generic.GenericDatumReader;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.io.DatumReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 排序段读取器
 * 
 * 从Avro格式的溢写文件中读取已排序的记录。
 * 支持迭代访问和资源管理。
 */
public class SortedRunReader implements AutoCloseable, Iterator<GenericRecord> {

    private static final Logger LOG = LoggerFactory.getLogger(SortedRunReader.class);

    private final Path filePath;
    private final DataFileReader<GenericRecord> reader;
    private final Schema schema;
    private final AtomicLong recordsRead;
    private GenericRecord currentRecord;
    private volatile boolean closed;

    /**
     * 创建排序段读取器
     *
     * @param filePath 输入文件路径
     * @throws IOException 如果创建失败
     */
    public SortedRunReader(Path filePath) throws IOException {
        this(filePath, null);
    }

    /**
     * 创建排序段读取器
     *
     * @param filePath 输入文件路径
     * @param schema 指定的Schema（可为null，使用文件中的Schema）
     * @throws IOException 如果创建失败
     */
    public SortedRunReader(Path filePath, Schema schema) throws IOException {
        this.filePath = filePath;
        this.recordsRead = new AtomicLong(0);
        this.closed = false;
        
        // 创建读取器
        DatumReader<GenericRecord> datumReader;
        if (schema != null) {
            datumReader = new GenericDatumReader<>(schema);
        } else {
            datumReader = new GenericDatumReader<>();
        }
        
        this.reader = new DataFileReader<>(filePath.toFile(), datumReader);
        this.schema = this.reader.getSchema();
        this.currentRecord = null;
        
        LOG.debug("Created SortedRunReader for file: {}", filePath);
    }

    @Override
    public boolean hasNext() {
        if (closed) {
            return false;
        }
        return reader.hasNext();
    }

    @Override
    public GenericRecord next() {
        if (closed) {
            throw new IllegalStateException("SortedRunReader has been closed");
        }
        if (!reader.hasNext()) {
            throw new NoSuchElementException("No more records");
        }
        
        try {
            // 复用记录对象以减少GC压力
            currentRecord = reader.next(currentRecord);
            recordsRead.incrementAndGet();
            return currentRecord;
        } catch (Exception e) {
            LOG.error("Error reading record from {}", filePath, e);
            throw new RuntimeException("Failed to read record", e);
        }
    }

    /**
     * 查看下一条记录但不消费
     *
     * @return 下一条记录，如果没有则返回null
     */
    public GenericRecord peek() {
        if (closed || !reader.hasNext()) {
            return null;
        }
        
        try {
            currentRecord = reader.next(currentRecord);
            recordsRead.incrementAndGet();
            return currentRecord;
        } catch (Exception e) {
            LOG.error("Error peeking record from {}", filePath, e);
            return null;
        }
    }

    /**
     * 获取已读取的记录数
     */
    public long getRecordsRead() {
        return recordsRead.get();
    }

    /**
     * 获取文件路径
     */
    public Path getFilePath() {
        return filePath;
    }

    /**
     * 获取Schema
     */
    public Schema getSchema() {
        return schema;
    }

    /**
     * 检查是否已关闭
     */
    public boolean isClosed() {
        return closed;
    }

    @Override
    public void close() throws IOException {
        if (!closed) {
            closed = true;
            try {
                reader.close();
                LOG.debug("Closed SortedRunReader: {}, records read: {}", 
                        filePath, recordsRead.get());
            } catch (IOException e) {
                LOG.error("Error closing SortedRunReader: {}", filePath, e);
                throw e;
            }
        }
    }
}
