package com.huawei.bigdata.sorter;

import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.parquet.avro.AvroParquetReader;
import org.apache.parquet.hadoop.ParquetReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.ReentrantLock;

/**
 * 外部排序器
 * 
 * 对大型Parquet文件执行外部排序，输出去重后的Avro记录迭代器。
 * 
 * <h2>主要特性</h2>
 * <ul>
 *   <li>多线程并行排序和溢写</li>
 *   <li>多磁盘负载均衡</li>
 *   <li>内存限制和OOM防护</li>
 *   <li>按排序键自动去重</li>
 *   <li>完善的异常处理和资源清理</li>
 * </ul>
 * 
 * <h2>使用示例</h2>
 * <pre>{@code
 * ExternalSorterConfig config = ExternalSorterConfig.builder()
 *     .memoryLimit(1024L * 1024 * 1024)  // 1GB
 *     .parallelism(8)
 *     .addSpillDirectory(Path.of("/disk1/spill"))
 *     .addSpillDirectory(Path.of("/disk2/spill"))
 *     .build();
 * 
 * try (ExternalSorter sorter = new ExternalSorter(config)) {
 *     Iterator<GenericRecord> result = sorter.sort(
 *         "/data/input.parquet",
 *         Arrays.asList("userId", "timestamp"),
 *         MergeFunction.keepLatest()
 *     );
 *     
 *     while (result.hasNext()) {
 *         GenericRecord record = result.next();
 *         // 处理记录...
 *     }
 * }
 * }</pre>
 */
public class ExternalSorter implements AutoCloseable {

    private static final Logger LOG = LoggerFactory.getLogger(ExternalSorter.class);

    /** 会话ID前缀 */
    private static final String SESSION_PREFIX = "sort_";

    private final ExternalSorterConfig config;
    private final String sessionId;
    private final ExecutorService executor;
    private final DiskManager diskManager;
    private final MemoryTracker memoryTracker;
    private final ReentrantLock sortLock;
    private final AtomicBoolean isSorting;
    private final AtomicBoolean closed;
    
    // 统计信息
    private final AtomicLong totalRecordsRead;
    private final AtomicLong totalRecordsOutput;
    private final AtomicLong totalSpillCount;
    private final AtomicLong sortStartTime;
    private final AtomicLong sortEndTime;

    /**
     * 创建外部排序器
     *
     * @param config 排序器配置
     * @throws IOException 如果初始化失败
     */
    public ExternalSorter(ExternalSorterConfig config) throws IOException {
        this.config = Objects.requireNonNull(config, "Config cannot be null");
        this.sessionId = SESSION_PREFIX + System.currentTimeMillis() + "_" + 
                         Thread.currentThread().getId();
        this.executor = createExecutor();
        this.diskManager = new DiskManager(config, sessionId);
        this.memoryTracker = new MemoryTracker(config.getMemoryLimit());
        this.sortLock = new ReentrantLock();
        this.isSorting = new AtomicBoolean(false);
        this.closed = new AtomicBoolean(false);
        
        this.totalRecordsRead = new AtomicLong(0);
        this.totalRecordsOutput = new AtomicLong(0);
        this.totalSpillCount = new AtomicLong(0);
        this.sortStartTime = new AtomicLong(0);
        this.sortEndTime = new AtomicLong(0);
        
        LOG.info("ExternalSorter initialized with session: {}", sessionId);
        LOG.info("Configuration: {}", config);
    }

    /**
     * 创建线程池
     */
    private ExecutorService createExecutor() {
        ThreadFactory threadFactory = new ThreadFactory() {
            private final AtomicInteger threadNumber = new AtomicInteger(1);
            
            @Override
            public Thread newThread(Runnable r) {
                Thread t = new Thread(r, "sorter-" + sessionId + "-" + threadNumber.getAndIncrement());
                t.setDaemon(true);
                return t;
            }
        };
        
        return new ThreadPoolExecutor(
                config.getParallelism(),
                config.getParallelism(),
                60L, TimeUnit.SECONDS,
                new LinkedBlockingQueue<>(config.getParallelism() * 2),
                threadFactory,
                new ThreadPoolExecutor.CallerRunsPolicy()
        );
    }

    /**
     * 执行外部排序
     * 
     * 此方法是线程安全的，同一时间只允许一个排序任务执行。
     *
     * @param parquetFilePath Parquet文件路径
     * @param sortKeys 排序键列表
     * @param mergeFunction 合并函数（用于去重）
     * @return 排序后的Avro记录迭代器
     * @throws IOException 如果排序失败
     */
    public Iterator<GenericRecord> sort(String parquetFilePath, 
                                        List<String> sortKeys,
                                        MergeFunction<GenericRecord> mergeFunction) throws IOException {
        return sort(parquetFilePath, sortKeys, null, mergeFunction);
    }

    /**
     * 执行外部排序（支持指定排序方向）
     *
     * @param parquetFilePath Parquet文件路径
     * @param sortKeys 排序键列表
     * @param ascending 升序/降序配置（null表示全部升序）
     * @param mergeFunction 合并函数（用于去重）
     * @return 排序后的Avro记录迭代器
     * @throws IOException 如果排序失败
     */
    public Iterator<GenericRecord> sort(String parquetFilePath,
                                        List<String> sortKeys,
                                        List<Boolean> ascending,
                                        MergeFunction<GenericRecord> mergeFunction) throws IOException {
        checkNotClosed();
        
        // 确保同时只有一个排序任务
        if (!isSorting.compareAndSet(false, true)) {
            throw new IllegalStateException("Another sort operation is already in progress");
        }
        
        sortLock.lock();
        try {
            LOG.info("Starting external sort for file: {}", parquetFilePath);
            LOG.info("Sort keys: {}", sortKeys);
            sortStartTime.set(System.currentTimeMillis());
            
            // 验证参数
            Objects.requireNonNull(parquetFilePath, "Parquet file path cannot be null");
            Objects.requireNonNull(sortKeys, "Sort keys cannot be null");
            Objects.requireNonNull(mergeFunction, "Merge function cannot be null");
            if (sortKeys.isEmpty()) {
                throw new IllegalArgumentException("Sort keys cannot be empty");
            }
            
            // 读取Schema
            Schema schema = readSchema(parquetFilePath);
            LOG.info("Schema loaded: {} fields", schema.getFields().size());
            
            // 验证排序键
            validateSortKeys(schema, sortKeys);
            
            // 创建比较器
            RecordComparator comparator = new RecordComparator(sortKeys, ascending);
            
            // 执行外部排序
            List<java.nio.file.Path> spillFiles = doExternalSort(parquetFilePath, schema, comparator);
            
            sortEndTime.set(System.currentTimeMillis());
            LOG.info("Sort phase completed in {} ms, {} spill files created",
                    sortEndTime.get() - sortStartTime.get(), spillFiles.size());
            
            // 创建合并迭代器
            if (spillFiles.isEmpty()) {
                LOG.info("No data to sort, returning empty iterator");
                return Collections.emptyIterator();
            }
            
            return createMergingIterator(spillFiles, schema, comparator, mergeFunction);
            
        } catch (Exception e) {
            LOG.error("External sort failed", e);
            cleanupOnError();
            throw new IOException("External sort failed: " + e.getMessage(), e);
        } finally {
            isSorting.set(false);
            sortLock.unlock();
        }
    }

    /**
     * 读取Parquet文件的Schema
     */
    private Schema readSchema(String parquetFilePath) throws IOException {
        Configuration conf = new Configuration();
        Path path = new Path(parquetFilePath);
        
        try (ParquetReader<GenericRecord> reader = AvroParquetReader
                .<GenericRecord>builder(path)
                .withConf(conf)
                .build()) {
            
            GenericRecord firstRecord = reader.read();
            if (firstRecord == null) {
                throw new IOException("Cannot read schema from empty Parquet file");
            }
            return firstRecord.getSchema();
        }
    }

    /**
     * 验证排序键是否存在于Schema中
     */
    private void validateSortKeys(Schema schema, List<String> sortKeys) {
        for (String key : sortKeys) {
            if (schema.getField(key) == null) {
                throw new IllegalArgumentException(
                        "Sort key '" + key + "' not found in schema. Available fields: " +
                        schema.getFields().stream().map(Schema.Field::name).toList());
            }
        }
    }

    /**
     * 执行外部排序核心逻辑
     */
    private List<java.nio.file.Path> doExternalSort(String parquetFilePath,
                                                     Schema schema,
                                                     RecordComparator comparator) throws Exception {
        List<java.nio.file.Path> spillFiles = Collections.synchronizedList(new ArrayList<>());
        List<GenericRecord> buffer = new ArrayList<>();
        long bufferMemory = 0;
        
        Configuration conf = new Configuration();
        Path path = new Path(parquetFilePath);
        
        // 使用线程安全的计数器
        AtomicLong recordCount = new AtomicLong(0);
        List<Future<?>> spillFutures = new ArrayList<>();
        
        try (ParquetReader<GenericRecord> reader = AvroParquetReader
                .<GenericRecord>builder(path)
                .withConf(conf)
                .build()) {
            
            GenericRecord record;
            while ((record = reader.read()) != null) {
                // 复制记录（因为ParquetReader会复用对象）
                GenericRecord copy = copyRecord(record, schema);
                long recordSize = MemoryTracker.estimateRecordSize(copy);
                
                // 检查是否需要申请内存
                if (!memoryTracker.tryAcquire(recordSize)) {
                    // 内存不足，触发溢写
                    LOG.info("Memory limit reached, triggering spill. Buffer size: {}, Memory used: {} MB",
                            buffer.size(), memoryTracker.getUsedMemory() / (1024.0 * 1024));
                    
                    Future<?> spillFuture = submitSpillTask(buffer, schema, comparator, spillFiles);
                    spillFutures.add(spillFuture);
                    
                    // 清空缓冲区
                    buffer = new ArrayList<>();
                    bufferMemory = 0;
                    
                    // 等待至少一个溢写完成以释放内存
                    waitForAnySpillComplete(spillFutures);
                    
                    // 重新尝试获取内存
                    if (!memoryTracker.acquire(recordSize, 30000)) {
                        throw new IOException("Failed to acquire memory after spill");
                    }
                }
                
                buffer.add(copy);
                bufferMemory += recordSize;
                recordCount.incrementAndGet();
                
                // 定期检查是否需要溢写
                if (memoryTracker.shouldSpill() && buffer.size() >= config.getBatchSize()) {
                    LOG.debug("Proactive spill triggered, buffer size: {}", buffer.size());
                    Future<?> spillFuture = submitSpillTask(buffer, schema, comparator, spillFiles);
                    spillFutures.add(spillFuture);
                    buffer = new ArrayList<>();
                    bufferMemory = 0;
                }
            }
            
            // 处理最后一批数据
            if (!buffer.isEmpty()) {
                LOG.info("Processing final buffer, size: {}", buffer.size());
                Future<?> spillFuture = submitSpillTask(buffer, schema, comparator, spillFiles);
                spillFutures.add(spillFuture);
            }
            
            // 等待所有溢写完成
            waitForAllSpills(spillFutures);
            
            totalRecordsRead.set(recordCount.get());
            totalSpillCount.set(spillFiles.size());
            
            LOG.info("Read phase completed: {} records read, {} spill files created",
                    recordCount.get(), spillFiles.size());
        }
        
        // 如果溢写文件过多，执行多阶段合并
        return mergeSpillFilesIfNeeded(spillFiles, schema, comparator);
    }

    /**
     * 提交溢写任务
     */
    private Future<?> submitSpillTask(List<GenericRecord> buffer,
                                      Schema schema,
                                      RecordComparator comparator,
                                      List<java.nio.file.Path> spillFiles) {
        // 计算缓冲区内存
        long bufferMemory = buffer.stream()
                .mapToLong(MemoryTracker::estimateRecordSize)
                .sum();
        
        final List<GenericRecord> finalBuffer = new ArrayList<>(buffer);
        final long finalBufferMemory = bufferMemory;
        
        return executor.submit(() -> {
            java.nio.file.Path spillFile = null;
            try {
                LOG.debug("Spill task started, sorting {} records", finalBuffer.size());
                
                // 排序
                long sortStart = System.currentTimeMillis();
                finalBuffer.sort(comparator);
                LOG.debug("Sorting completed in {} ms", System.currentTimeMillis() - sortStart);
                
                // 去重（在同一个排序段内）
                List<GenericRecord> dedupedRecords = deduplicateInMemory(finalBuffer, comparator);
                LOG.debug("Deduplication: {} -> {} records", 
                        finalBuffer.size(), dedupedRecords.size());
                
                // 分配溢写文件
                spillFile = diskManager.allocateSpillFile("run", ".avro");
                
                // 写入文件
                long writeStart = System.currentTimeMillis();
                try (SortedRunWriter writer = new SortedRunWriter(
                        spillFile, schema, 
                        config.isEnableCompression(), 
                        config.getCompressionCodec())) {
                    writer.writeAll(dedupedRecords);
                }
                
                LOG.debug("Spill completed: {} records written to {} in {} ms",
                        dedupedRecords.size(), spillFile.getFileName(),
                        System.currentTimeMillis() - writeStart);
                
                spillFiles.add(spillFile);
                
            } catch (Exception e) {
                LOG.error("Spill task failed", e);
                // 清理失败的文件
                if (spillFile != null) {
                    diskManager.deleteFile(spillFile);
                }
                throw new RuntimeException("Spill failed", e);
            } finally {
                // 释放内存
                memoryTracker.release(finalBufferMemory);
            }
        });
    }

    /**
     * 内存中去重
     */
    private List<GenericRecord> deduplicateInMemory(List<GenericRecord> sortedRecords,
                                                     RecordComparator comparator) {
        if (sortedRecords.isEmpty()) {
            return sortedRecords;
        }
        
        List<GenericRecord> result = new ArrayList<>();
        GenericRecord prev = sortedRecords.get(0);
        result.add(prev);
        
        for (int i = 1; i < sortedRecords.size(); i++) {
            GenericRecord current = sortedRecords.get(i);
            if (!comparator.keysEqual(prev, current)) {
                result.add(current);
                prev = current;
            }
        }
        
        return result;
    }

    /**
     * 等待任意一个溢写完成
     */
    private void waitForAnySpillComplete(List<Future<?>> futures) throws Exception {
        while (true) {
            for (Iterator<Future<?>> it = futures.iterator(); it.hasNext(); ) {
                Future<?> future = it.next();
                if (future.isDone()) {
                    future.get(); // 检查异常
                    it.remove();
                    return;
                }
            }
            Thread.sleep(10);
        }
    }

    /**
     * 等待所有溢写完成
     */
    private void waitForAllSpills(List<Future<?>> futures) throws Exception {
        for (Future<?> future : futures) {
            future.get();
        }
    }

    /**
     * 如果溢写文件过多，执行多阶段合并
     */
    private List<java.nio.file.Path> mergeSpillFilesIfNeeded(
            List<java.nio.file.Path> spillFiles,
            Schema schema,
            RecordComparator comparator) throws Exception {
        
        if (spillFiles.size() <= config.getMergeFactor()) {
            return spillFiles;
        }
        
        LOG.info("Too many spill files ({}), performing intermediate merge (factor: {})",
                spillFiles.size(), config.getMergeFactor());
        
        List<java.nio.file.Path> currentFiles = new ArrayList<>(spillFiles);
        int round = 1;
        
        while (currentFiles.size() > config.getMergeFactor()) {
            LOG.info("Merge round {}: {} files -> ~{} files",
                    round, currentFiles.size(), 
                    (currentFiles.size() + config.getMergeFactor() - 1) / config.getMergeFactor());
            
            List<java.nio.file.Path> newFiles = new ArrayList<>();
            List<Future<java.nio.file.Path>> mergeFutures = new ArrayList<>();
            
            // 分批合并
            for (int i = 0; i < currentFiles.size(); i += config.getMergeFactor()) {
                int end = Math.min(i + config.getMergeFactor(), currentFiles.size());
                List<java.nio.file.Path> batch = currentFiles.subList(i, end);
                
                Future<java.nio.file.Path> future = executor.submit(() -> {
                    return mergeFiles(batch, schema, comparator);
                });
                mergeFutures.add(future);
            }
            
            // 等待所有合并完成
            for (Future<java.nio.file.Path> future : mergeFutures) {
                newFiles.add(future.get());
            }
            
            // 清理旧文件
            for (java.nio.file.Path oldFile : currentFiles) {
                diskManager.deleteFile(oldFile);
            }
            
            currentFiles = newFiles;
            round++;
        }
        
        LOG.info("Intermediate merge completed: {} files remaining", currentFiles.size());
        return currentFiles;
    }

    /**
     * 合并多个文件为一个
     */
    private java.nio.file.Path mergeFiles(List<java.nio.file.Path> files,
                                           Schema schema,
                                           RecordComparator comparator) throws Exception {
        java.nio.file.Path outputFile = diskManager.allocateSpillFile("merged", ".avro");
        
        List<SortedRunReader> readers = new ArrayList<>();
        try {
            for (java.nio.file.Path file : files) {
                readers.add(new SortedRunReader(file, schema));
            }
            
            try (MergingIterator merger = new MergingIterator(
                    readers, comparator, MergeFunction.keepLatest(), schema);
                 SortedRunWriter writer = new SortedRunWriter(
                         outputFile, schema,
                         config.isEnableCompression(),
                         config.getCompressionCodec())) {
                
                while (merger.hasNext()) {
                    writer.write(merger.next());
                }
            }
            
            LOG.debug("Merged {} files into {}", files.size(), outputFile.getFileName());
            return outputFile;
            
        } finally {
            for (SortedRunReader reader : readers) {
                try {
                    reader.close();
                } catch (IOException e) {
                    LOG.warn("Failed to close reader", e);
                }
            }
        }
    }

    /**
     * 创建最终的合并迭代器
     */
    private Iterator<GenericRecord> createMergingIterator(
            List<java.nio.file.Path> spillFiles,
            Schema schema,
            RecordComparator comparator,
            MergeFunction<GenericRecord> mergeFunction) throws IOException {
        
        List<SortedRunReader> readers = new ArrayList<>();
        try {
            for (java.nio.file.Path file : spillFiles) {
                readers.add(new SortedRunReader(file, schema));
            }
            
            MergingIterator mergingIterator = new MergingIterator(
                    readers, comparator, mergeFunction, schema);
            
            // 包装迭代器，在完成时清理资源
            return new CleanupIterator(mergingIterator, spillFiles, diskManager);
            
        } catch (Exception e) {
            // 清理已创建的reader
            for (SortedRunReader reader : readers) {
                try {
                    reader.close();
                } catch (IOException ex) {
                    LOG.warn("Failed to close reader during error handling", ex);
                }
            }
            throw e;
        }
    }

    /**
     * 复制记录
     */
    private GenericRecord copyRecord(GenericRecord source, Schema schema) {
        GenericRecord copy = new GenericData.Record(schema);
        for (Schema.Field field : schema.getFields()) {
            copy.put(field.pos(), source.get(field.pos()));
        }
        return copy;
    }

    /**
     * 错误时清理资源
     */
    private void cleanupOnError() {
        try {
            diskManager.cleanup();
        } catch (Exception e) {
            LOG.error("Cleanup failed", e);
        }
    }

    /**
     * 获取排序统计信息
     */
    public String getStats() {
        long duration = sortEndTime.get() > 0 
                ? sortEndTime.get() - sortStartTime.get() 
                : System.currentTimeMillis() - sortStartTime.get();
        
        return String.format(
                "ExternalSorter Stats:\n" +
                "  Session: %s\n" +
                "  Records Read: %d\n" +
                "  Records Output: %d\n" +
                "  Spill Files: %d\n" +
                "  Duration: %d ms\n" +
                "%s\n" +
                "%s",
                sessionId,
                totalRecordsRead.get(),
                totalRecordsOutput.get(),
                totalSpillCount.get(),
                duration,
                memoryTracker.getStats(),
                diskManager.getDiskUsageStats()
        );
    }

    private void checkNotClosed() {
        if (closed.get()) {
            throw new IllegalStateException("ExternalSorter has been closed");
        }
    }

    @Override
    public void close() throws IOException {
        if (closed.compareAndSet(false, true)) {
            LOG.info("Closing ExternalSorter...");
            
            // 关闭线程池
            executor.shutdown();
            try {
                if (!executor.awaitTermination(30, TimeUnit.SECONDS)) {
                    executor.shutdownNow();
                }
            } catch (InterruptedException e) {
                executor.shutdownNow();
                Thread.currentThread().interrupt();
            }
            
            // 清理磁盘
            diskManager.close();
            
            LOG.info("ExternalSorter closed. Final stats:\n{}", getStats());
        }
    }

    /**
     * 清理迭代器包装类
     * 在迭代完成或关闭时自动清理临时文件
     */
    private static class CleanupIterator implements Iterator<GenericRecord>, AutoCloseable {
        
        private final MergingIterator delegate;
        private final List<java.nio.file.Path> spillFiles;
        private final DiskManager diskManager;
        private volatile boolean closed;
        
        CleanupIterator(MergingIterator delegate, 
                        List<java.nio.file.Path> spillFiles,
                        DiskManager diskManager) {
            this.delegate = delegate;
            this.spillFiles = spillFiles;
            this.diskManager = diskManager;
            this.closed = false;
        }
        
        @Override
        public boolean hasNext() {
            boolean hasNext = delegate.hasNext();
            if (!hasNext && !closed) {
                cleanup();
            }
            return hasNext;
        }
        
        @Override
        public GenericRecord next() {
            return delegate.next();
        }
        
        private void cleanup() {
            if (!closed) {
                closed = true;
                try {
                    delegate.close();
                } catch (IOException e) {
                    LOG.warn("Failed to close merging iterator", e);
                }
                
                for (java.nio.file.Path file : spillFiles) {
                    diskManager.deleteFile(file);
                }
                LOG.debug("Cleanup completed: {} spill files deleted", spillFiles.size());
            }
        }
        
        @Override
        public void close() {
            cleanup();
        }
    }
}
