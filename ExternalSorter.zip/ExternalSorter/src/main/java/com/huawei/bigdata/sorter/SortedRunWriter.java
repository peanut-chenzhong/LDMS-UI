package com.huawei.bigdata.sorter;

import org.apache.avro.Schema;
import org.apache.avro.file.CodecFactory;
import org.apache.avro.file.DataFileWriter;
import org.apache.avro.generic.GenericDatumWriter;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.io.DatumWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 排序段写入器
 * 
 * 将已排序的记录写入Avro格式的溢写文件。
 * 支持压缩和批量写入优化。
 */
public class SortedRunWriter implements AutoCloseable {

    private static final Logger LOG = LoggerFactory.getLogger(SortedRunWriter.class);
    
    /** 默认缓冲区大小：8MB */
    private static final int DEFAULT_BUFFER_SIZE = 8 * 1024 * 1024;
    
    /** 同步间隔（记录数） */
    private static final int SYNC_INTERVAL = 64 * 1024;

    private final Path filePath;
    private final Schema schema;
    private final DataFileWriter<GenericRecord> writer;
    private final AtomicLong recordCount;
    private final AtomicLong bytesWritten;
    private final boolean enableCompression;
    private final String compressionCodec;
    private volatile boolean closed;

    /**
     * 创建排序段写入器
     *
     * @param filePath 输出文件路径
     * @param schema Avro Schema
     * @param enableCompression 是否启用压缩
     * @param compressionCodec 压缩编码
     * @throws IOException 如果创建失败
     */
    public SortedRunWriter(Path filePath, Schema schema, boolean enableCompression, 
                           String compressionCodec) throws IOException {
        this.filePath = filePath;
        this.schema = schema;
        this.enableCompression = enableCompression;
        this.compressionCodec = compressionCodec;
        this.recordCount = new AtomicLong(0);
        this.bytesWritten = new AtomicLong(0);
        this.closed = false;
        
        // 创建写入器
        DatumWriter<GenericRecord> datumWriter = new GenericDatumWriter<>(schema);
        this.writer = new DataFileWriter<>(datumWriter);
        
        // 配置压缩
        if (enableCompression) {
            CodecFactory codec = createCodecFactory(compressionCodec);
            writer.setCodec(codec);
        }
        
        // 设置同步间隔
        writer.setSyncInterval(SYNC_INTERVAL);
        
        // 创建输出流
        OutputStream os = new BufferedOutputStream(
                Files.newOutputStream(filePath), DEFAULT_BUFFER_SIZE);
        writer.create(schema, os);
        
        LOG.debug("Created SortedRunWriter for file: {}, compression: {}", 
                filePath, enableCompression ? compressionCodec : "none");
    }

    /**
     * 创建压缩编码工厂
     */
    private CodecFactory createCodecFactory(String codec) {
        switch (codec.toLowerCase()) {
            case "snappy":
                return CodecFactory.snappyCodec();
            case "deflate":
                return CodecFactory.deflateCodec(6);
            case "bzip2":
                return CodecFactory.bzip2Codec();
            case "xz":
                return CodecFactory.xzCodec(6);
            case "zstandard":
            case "zstd":
                return CodecFactory.zstandardCodec(3);
            default:
                LOG.warn("Unknown compression codec: {}, using snappy", codec);
                return CodecFactory.snappyCodec();
        }
    }

    /**
     * 写入单条记录
     *
     * @param record 要写入的记录
     * @throws IOException 如果写入失败
     */
    public void write(GenericRecord record) throws IOException {
        checkNotClosed();
        writer.append(record);
        recordCount.incrementAndGet();
    }

    /**
     * 批量写入记录
     *
     * @param records 记录迭代器
     * @throws IOException 如果写入失败
     */
    public void writeAll(Iterable<GenericRecord> records) throws IOException {
        checkNotClosed();
        for (GenericRecord record : records) {
            writer.append(record);
            recordCount.incrementAndGet();
        }
    }

    /**
     * 刷新缓冲区
     *
     * @throws IOException 如果刷新失败
     */
    public void flush() throws IOException {
        checkNotClosed();
        writer.flush();
    }

    /**
     * 获取已写入的记录数
     */
    public long getRecordCount() {
        return recordCount.get();
    }

    /**
     * 获取文件路径
     */
    public Path getFilePath() {
        return filePath;
    }

    /**
     * 获取文件大小（在关闭后有效）
     */
    public long getFileSize() {
        try {
            return Files.size(filePath);
        } catch (IOException e) {
            return bytesWritten.get();
        }
    }

    /**
     * 获取Schema
     */
    public Schema getSchema() {
        return schema;
    }

    private void checkNotClosed() {
        if (closed) {
            throw new IllegalStateException("SortedRunWriter has been closed");
        }
    }

    @Override
    public void close() throws IOException {
        if (!closed) {
            closed = true;
            try {
                writer.close();
                bytesWritten.set(Files.size(filePath));
                LOG.debug("Closed SortedRunWriter: {}, records: {}, size: {} MB",
                        filePath, recordCount.get(), bytesWritten.get() / (1024.0 * 1024));
            } catch (IOException e) {
                LOG.error("Error closing SortedRunWriter: {}", filePath, e);
                throw e;
            }
        }
    }
}
