package com.huawei.bigdata.sorter;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * 外部排序器配置类
 * 
 * 提供外部排序所需的各种配置参数，包括内存限制、磁盘配置、并行度等。
 */
public class ExternalSorterConfig {

    /** 默认内存限制：512MB */
    public static final long DEFAULT_MEMORY_LIMIT = 512L * 1024 * 1024;
    
    /** 默认排序缓冲区大小：64MB */
    public static final long DEFAULT_SORT_BUFFER_SIZE = 64L * 1024 * 1024;
    
    /** 默认并行度：CPU核心数 */
    public static final int DEFAULT_PARALLELISM = Runtime.getRuntime().availableProcessors();
    
    /** 默认批量读取大小 */
    public static final int DEFAULT_BATCH_SIZE = 10000;
    
    /** 默认合并因子 */
    public static final int DEFAULT_MERGE_FACTOR = 16;

    private final long memoryLimit;
    private final long sortBufferSize;
    private final List<Path> spillDirectories;
    private final int parallelism;
    private final int batchSize;
    private final int mergeFactor;
    private final boolean enableCompression;
    private final String compressionCodec;

    private ExternalSorterConfig(Builder builder) {
        this.memoryLimit = builder.memoryLimit;
        this.sortBufferSize = builder.sortBufferSize;
        this.spillDirectories = Collections.unmodifiableList(new ArrayList<>(builder.spillDirectories));
        this.parallelism = builder.parallelism;
        this.batchSize = builder.batchSize;
        this.mergeFactor = builder.mergeFactor;
        this.enableCompression = builder.enableCompression;
        this.compressionCodec = builder.compressionCodec;
    }

    /**
     * 获取内存限制（字节）
     */
    public long getMemoryLimit() {
        return memoryLimit;
    }

    /**
     * 获取排序缓冲区大小（字节）
     */
    public long getSortBufferSize() {
        return sortBufferSize;
    }

    /**
     * 获取溢写目录列表（支持多磁盘）
     */
    public List<Path> getSpillDirectories() {
        return spillDirectories;
    }

    /**
     * 获取并行度
     */
    public int getParallelism() {
        return parallelism;
    }

    /**
     * 获取批量读取大小
     */
    public int getBatchSize() {
        return batchSize;
    }

    /**
     * 获取合并因子
     */
    public int getMergeFactor() {
        return mergeFactor;
    }

    /**
     * 是否启用压缩
     */
    public boolean isEnableCompression() {
        return enableCompression;
    }

    /**
     * 获取压缩编码
     */
    public String getCompressionCodec() {
        return compressionCodec;
    }

    /**
     * 创建默认配置
     */
    public static ExternalSorterConfig defaultConfig() {
        return new Builder().build();
    }

    /**
     * 创建配置构建器
     */
    public static Builder builder() {
        return new Builder();
    }

    @Override
    public String toString() {
        return "ExternalSorterConfig{" +
                "memoryLimit=" + memoryLimit +
                ", sortBufferSize=" + sortBufferSize +
                ", spillDirectories=" + spillDirectories +
                ", parallelism=" + parallelism +
                ", batchSize=" + batchSize +
                ", mergeFactor=" + mergeFactor +
                ", enableCompression=" + enableCompression +
                ", compressionCodec='" + compressionCodec + '\'' +
                '}';
    }

    /**
     * 配置构建器
     */
    public static class Builder {
        private long memoryLimit = DEFAULT_MEMORY_LIMIT;
        private long sortBufferSize = DEFAULT_SORT_BUFFER_SIZE;
        private List<Path> spillDirectories = new ArrayList<>();
        private int parallelism = DEFAULT_PARALLELISM;
        private int batchSize = DEFAULT_BATCH_SIZE;
        private int mergeFactor = DEFAULT_MERGE_FACTOR;
        private boolean enableCompression = true;
        private String compressionCodec = "snappy";

        /**
         * 设置内存限制
         * @param memoryLimit 内存限制（字节）
         */
        public Builder memoryLimit(long memoryLimit) {
            if (memoryLimit <= 0) {
                throw new IllegalArgumentException("Memory limit must be positive");
            }
            this.memoryLimit = memoryLimit;
            return this;
        }

        /**
         * 设置排序缓冲区大小
         * @param sortBufferSize 缓冲区大小（字节）
         */
        public Builder sortBufferSize(long sortBufferSize) {
            if (sortBufferSize <= 0) {
                throw new IllegalArgumentException("Sort buffer size must be positive");
            }
            this.sortBufferSize = sortBufferSize;
            return this;
        }

        /**
         * 添加溢写目录（支持多磁盘）
         * @param directory 目录路径
         */
        public Builder addSpillDirectory(Path directory) {
            Objects.requireNonNull(directory, "Spill directory cannot be null");
            this.spillDirectories.add(directory);
            return this;
        }

        /**
         * 设置溢写目录列表
         * @param directories 目录列表
         */
        public Builder spillDirectories(List<Path> directories) {
            Objects.requireNonNull(directories, "Spill directories cannot be null");
            this.spillDirectories = new ArrayList<>(directories);
            return this;
        }

        /**
         * 设置并行度
         * @param parallelism 并行线程数
         */
        public Builder parallelism(int parallelism) {
            if (parallelism <= 0) {
                throw new IllegalArgumentException("Parallelism must be positive");
            }
            this.parallelism = parallelism;
            return this;
        }

        /**
         * 设置批量读取大小
         * @param batchSize 批量大小
         */
        public Builder batchSize(int batchSize) {
            if (batchSize <= 0) {
                throw new IllegalArgumentException("Batch size must be positive");
            }
            this.batchSize = batchSize;
            return this;
        }

        /**
         * 设置合并因子
         * @param mergeFactor 合并因子
         */
        public Builder mergeFactor(int mergeFactor) {
            if (mergeFactor < 2) {
                throw new IllegalArgumentException("Merge factor must be at least 2");
            }
            this.mergeFactor = mergeFactor;
            return this;
        }

        /**
         * 设置是否启用压缩
         * @param enableCompression 是否启用
         */
        public Builder enableCompression(boolean enableCompression) {
            this.enableCompression = enableCompression;
            return this;
        }

        /**
         * 设置压缩编码
         * @param compressionCodec 压缩编码名称
         */
        public Builder compressionCodec(String compressionCodec) {
            Objects.requireNonNull(compressionCodec, "Compression codec cannot be null");
            this.compressionCodec = compressionCodec;
            return this;
        }

        /**
         * 构建配置对象
         */
        public ExternalSorterConfig build() {
            // 如果没有配置溢写目录，使用系统临时目录
            if (spillDirectories.isEmpty()) {
                spillDirectories.add(Path.of(System.getProperty("java.io.tmpdir"), "external-sorter"));
            }
            return new ExternalSorterConfig(this);
        }
    }
}
