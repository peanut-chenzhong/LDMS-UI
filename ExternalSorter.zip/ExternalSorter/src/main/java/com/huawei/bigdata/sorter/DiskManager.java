package com.huawei.bigdata.sorter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 磁盘管理器
 * 
 * 管理多个磁盘目录的溢写文件，实现负载均衡和临时文件清理。
 * 支持轮询和基于可用空间的目录选择策略。
 */
public class DiskManager implements AutoCloseable {

    private static final Logger LOG = LoggerFactory.getLogger(DiskManager.class);

    private final List<Path> spillDirectories;
    private final AtomicInteger roundRobinIndex;
    private final AtomicLong fileCounter;
    private final ConcurrentMap<Path, AtomicLong> directoryUsage;
    private final ConcurrentMap<String, List<Path>> sessionFiles;
    private final String sessionId;
    private volatile boolean closed;

    /**
     * 创建磁盘管理器
     *
     * @param config 排序器配置
     * @param sessionId 会话ID，用于隔离不同排序任务的临时文件
     * @throws IOException 如果创建目录失败
     */
    public DiskManager(ExternalSorterConfig config, String sessionId) throws IOException {
        this.spillDirectories = new ArrayList<>(config.getSpillDirectories());
        this.roundRobinIndex = new AtomicInteger(0);
        this.fileCounter = new AtomicLong(0);
        this.directoryUsage = new ConcurrentHashMap<>();
        this.sessionFiles = new ConcurrentHashMap<>();
        this.sessionId = sessionId;
        this.closed = false;

        // 初始化溢写目录
        initializeDirectories();
        
        LOG.info("DiskManager initialized with {} spill directories for session {}", 
                spillDirectories.size(), sessionId);
    }

    /**
     * 初始化所有溢写目录
     */
    private void initializeDirectories() throws IOException {
        for (Path dir : spillDirectories) {
            Path sessionDir = dir.resolve(sessionId);
            try {
                Files.createDirectories(sessionDir);
                directoryUsage.put(sessionDir, new AtomicLong(0));
                LOG.debug("Created spill directory: {}", sessionDir);
            } catch (IOException e) {
                LOG.error("Failed to create spill directory: {}", sessionDir, e);
                throw e;
            }
        }
    }

    /**
     * 分配一个新的溢写文件路径
     * 使用轮询策略在多个磁盘间分配
     *
     * @param prefix 文件名前缀
     * @param suffix 文件名后缀
     * @return 新的文件路径
     */
    public synchronized Path allocateSpillFile(String prefix, String suffix) {
        checkNotClosed();
        
        // 轮询选择目录
        int index = roundRobinIndex.getAndIncrement() % spillDirectories.size();
        Path baseDir = spillDirectories.get(index);
        Path sessionDir = baseDir.resolve(sessionId);
        
        // 生成唯一文件名
        long fileId = fileCounter.getAndIncrement();
        String fileName = String.format("%s_%d_%d%s", prefix, System.currentTimeMillis(), fileId, suffix);
        Path filePath = sessionDir.resolve(fileName);
        
        // 记录文件
        sessionFiles.computeIfAbsent(sessionId, k -> new ArrayList<>()).add(filePath);
        
        LOG.debug("Allocated spill file: {}", filePath);
        return filePath;
    }

    /**
     * 基于可用空间分配溢写文件
     * 选择可用空间最大的目录
     *
     * @param prefix 文件名前缀
     * @param suffix 文件名后缀
     * @return 新的文件路径
     */
    public synchronized Path allocateSpillFileBySpace(String prefix, String suffix) {
        checkNotClosed();
        
        // 选择可用空间最大的目录
        Path bestDir = spillDirectories.stream()
                .max(Comparator.comparingLong(this::getUsableSpace))
                .orElse(spillDirectories.get(0));
        
        Path sessionDir = bestDir.resolve(sessionId);
        
        // 生成唯一文件名
        long fileId = fileCounter.getAndIncrement();
        String fileName = String.format("%s_%d_%d%s", prefix, System.currentTimeMillis(), fileId, suffix);
        Path filePath = sessionDir.resolve(fileName);
        
        // 记录文件
        sessionFiles.computeIfAbsent(sessionId, k -> new ArrayList<>()).add(filePath);
        
        LOG.debug("Allocated spill file (by space): {} (usable: {} MB)", 
                filePath, getUsableSpace(bestDir) / (1024 * 1024));
        return filePath;
    }

    /**
     * 获取目录的可用空间
     */
    private long getUsableSpace(Path dir) {
        try {
            return Files.getFileStore(dir).getUsableSpace();
        } catch (IOException e) {
            LOG.warn("Failed to get usable space for {}: {}", dir, e.getMessage());
            return 0;
        }
    }

    /**
     * 注册一个临时文件（用于追踪清理）
     *
     * @param filePath 文件路径
     */
    public void registerFile(Path filePath) {
        sessionFiles.computeIfAbsent(sessionId, k -> new ArrayList<>()).add(filePath);
        LOG.trace("Registered file for cleanup: {}", filePath);
    }

    /**
     * 删除单个文件
     *
     * @param filePath 文件路径
     * @return 是否删除成功
     */
    public boolean deleteFile(Path filePath) {
        try {
            boolean deleted = Files.deleteIfExists(filePath);
            if (deleted) {
                LOG.debug("Deleted file: {}", filePath);
            }
            return deleted;
        } catch (IOException e) {
            LOG.warn("Failed to delete file: {}", filePath, e);
            return false;
        }
    }

    /**
     * 清理所有会话的临时文件
     */
    public void cleanup() {
        LOG.info("Starting cleanup for session: {}", sessionId);
        
        List<Path> files = sessionFiles.remove(sessionId);
        if (files != null) {
            int deleted = 0;
            int failed = 0;
            for (Path file : files) {
                if (deleteFile(file)) {
                    deleted++;
                } else {
                    failed++;
                }
            }
            LOG.info("Cleanup completed: {} files deleted, {} failed", deleted, failed);
        }
        
        // 清理空的会话目录
        for (Path dir : spillDirectories) {
            Path sessionDir = dir.resolve(sessionId);
            try {
                if (Files.exists(sessionDir) && isDirectoryEmpty(sessionDir)) {
                    Files.delete(sessionDir);
                    LOG.debug("Deleted empty session directory: {}", sessionDir);
                }
            } catch (IOException e) {
                LOG.warn("Failed to delete session directory: {}", sessionDir, e);
            }
        }
    }

    /**
     * 检查目录是否为空
     */
    private boolean isDirectoryEmpty(Path dir) throws IOException {
        try (var stream = Files.list(dir)) {
            return stream.findAny().isEmpty();
        }
    }

    /**
     * 获取当前会话的所有临时文件
     *
     * @return 文件路径列表
     */
    public List<Path> getSessionFiles() {
        return new ArrayList<>(sessionFiles.getOrDefault(sessionId, new ArrayList<>()));
    }

    /**
     * 获取总的溢写文件数量
     */
    public long getTotalFileCount() {
        return fileCounter.get();
    }

    /**
     * 获取磁盘使用统计
     *
     * @return 各目录的使用统计
     */
    public String getDiskUsageStats() {
        StringBuilder sb = new StringBuilder("Disk Usage Stats:\n");
        for (Path dir : spillDirectories) {
            long usable = getUsableSpace(dir);
            sb.append(String.format("  %s: %.2f GB usable\n", dir, usable / (1024.0 * 1024 * 1024)));
        }
        return sb.toString();
    }

    private void checkNotClosed() {
        if (closed) {
            throw new IllegalStateException("DiskManager has been closed");
        }
    }

    @Override
    public void close() {
        if (!closed) {
            closed = true;
            cleanup();
            LOG.info("DiskManager closed for session: {}", sessionId);
        }
    }
}
