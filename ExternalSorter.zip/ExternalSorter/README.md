# ExternalSorter - 高性能外部排序器

一个高性能的Java外部排序库，专门用于对大型Parquet文件进行排序和去重，输出Avro格式的记录迭代器。

## 特性

- **多线程并行排序**：利用多核CPU并行执行排序和溢写操作
- **多磁盘负载均衡**：支持配置多个溢写目录，自动在多个磁盘间分配负载
- **内存限制与OOM防护**：精确的内存追踪和控制，避免内存溢出
- **自动去重**：按排序键自动去重，支持自定义合并逻辑
- **线程安全**：完全线程安全的设计
- **完善的异常处理**：自动清理临时文件，确保资源正确释放
- **详细的日志输出**：使用SLF4J提供详细的运行日志

## 快速开始

### Maven依赖

```xml
<dependency>
    <groupId>com.huawei.bigdata</groupId>
    <artifactId>external-sorter</artifactId>
    <version>1.0.0</version>
</dependency>
```

### 基本使用

```java
import com.huawei.bigdata.sorter.*;
import org.apache.avro.generic.GenericRecord;
import java.nio.file.Path;
import java.util.*;

// 创建配置
ExternalSorterConfig config = ExternalSorterConfig.builder()
    .memoryLimit(1024L * 1024 * 1024)  // 1GB内存限制
    .sortBufferSize(128L * 1024 * 1024)  // 128MB排序缓冲区
    .parallelism(8)  // 8线程并行
    .addSpillDirectory(Path.of("/disk1/spill"))  // 磁盘1
    .addSpillDirectory(Path.of("/disk2/spill"))  // 磁盘2
    .enableCompression(true)
    .compressionCodec("snappy")
    .mergeFactor(16)
    .build();

// 执行排序
try (ExternalSorter sorter = new ExternalSorter(config)) {
    Iterator<GenericRecord> result = sorter.sort(
        "/data/input.parquet",           // 输入Parquet文件
        Arrays.asList("userId", "timestamp"),  // 排序键
        MergeFunction.keepLatest()        // 去重时保留最新记录
    );
    
    // 处理排序后的记录
    while (result.hasNext()) {
        GenericRecord record = result.next();
        // 处理记录...
    }
}
```

## 配置选项

| 配置项 | 默认值 | 说明 |
|--------|--------|------|
| `memoryLimit` | 512MB | 最大内存使用限制 |
| `sortBufferSize` | 64MB | 排序缓冲区大小 |
| `parallelism` | CPU核心数 | 并行线程数 |
| `spillDirectories` | 系统临时目录 | 溢写目录列表（支持多磁盘） |
| `batchSize` | 10000 | 批量读取大小 |
| `mergeFactor` | 16 | 合并因子（K路归并） |
| `enableCompression` | true | 是否启用压缩 |
| `compressionCodec` | snappy | 压缩编码（snappy/deflate/zstd等） |

## 合并函数

合并函数用于处理具有相同排序键的重复记录。提供以下预定义函数：

```java
// 保留最新（后出现的）记录
MergeFunction.keepLatest()

// 保留最早（先出现的）记录
MergeFunction.keepFirst()

// 根据指定字段选择（保留较大值）
MergeFunction.byField("timestamp", true)

// 根据指定字段选择（保留较小值）
MergeFunction.byField("priority", false)
```

### 自定义合并函数

```java
MergeFunction<GenericRecord> customMerge = (existing, incoming) -> {
    // 自定义合并逻辑
    // 例如：合并字段值
    GenericRecord merged = new GenericData.Record(existing.getSchema());
    for (Schema.Field field : existing.getSchema().getFields()) {
        if (field.name().equals("count")) {
            // 累加count字段
            long existingCount = (Long) existing.get("count");
            long incomingCount = (Long) incoming.get("count");
            merged.put("count", existingCount + incomingCount);
        } else {
            // 其他字段保留incoming的值
            merged.put(field.pos(), incoming.get(field.pos()));
        }
    }
    return merged;
};
```

## 多列排序

支持按多列排序，并可指定每列的排序方向：

```java
// 按name升序，timestamp降序
Iterator<GenericRecord> result = sorter.sort(
    "/data/input.parquet",
    Arrays.asList("name", "timestamp"),
    Arrays.asList(true, false),  // true=升序, false=降序
    MergeFunction.keepLatest()
);
```

## 架构设计

```
┌─────────────────────────────────────────────────────────────────┐
│                        ExternalSorter                           │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────────┐   ┌──────────────┐   ┌──────────────────┐    │
│  │ ParquetReader │   │ MemoryTracker │   │ RecordComparator │    │
│  └──────┬───────┘   └──────┬───────┘   └────────┬─────────┘    │
│         │                   │                     │              │
│         ▼                   ▼                     ▼              │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                    Sort Buffer (In-Memory)               │    │
│  └──────────────────────────┬──────────────────────────────┘    │
│                              │                                   │
│                    ┌─────────▼─────────┐                        │
│                    │   Parallel Sort   │                        │
│                    │   & Deduplication │                        │
│                    └─────────┬─────────┘                        │
│                              │                                   │
│         ┌────────────────────┼────────────────────┐             │
│         ▼                    ▼                    ▼             │
│  ┌─────────────┐      ┌─────────────┐      ┌─────────────┐     │
│  │ SortedRun 1 │      │ SortedRun 2 │      │ SortedRun N │     │
│  │  (Disk 1)   │      │  (Disk 2)   │      │  (Disk N)   │     │
│  └──────┬──────┘      └──────┬──────┘      └──────┬──────┘     │
│         │                    │                    │             │
│         └────────────────────┼────────────────────┘             │
│                              ▼                                   │
│                    ┌─────────────────┐                          │
│                    │ MergingIterator │                          │
│                    │ (K-way Merge)   │                          │
│                    └────────┬────────┘                          │
│                              │                                   │
│                              ▼                                   │
│                    ┌─────────────────┐                          │
│                    │ Output Iterator │                          │
│                    │ (Avro Records)  │                          │
│                    └─────────────────┘                          │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## 核心组件

### 1. ExternalSorter
主入口类，协调整个排序流程。

### 2. MemoryTracker
内存追踪器，精确控制内存使用，防止OOM。

### 3. DiskManager
磁盘管理器，支持多磁盘负载均衡和临时文件管理。

### 4. SortedRunWriter / SortedRunReader
溢写文件的写入和读取器。

### 5. MergingIterator
K路归并迭代器，使用小顶堆高效合并多个有序流。

### 6. RecordComparator
记录比较器，支持多列和自定义排序方向。

## 日志配置

使用SLF4J + Logback进行日志记录。默认配置：

```xml
<!-- logback.xml -->
<logger name="com.huawei.bigdata.sorter" level="INFO"/>
```

日志级别说明：
- **INFO**: 关键操作信息（开始/结束/统计）
- **DEBUG**: 详细操作信息（溢写/合并）
- **TRACE**: 最详细信息（每条记录级别）

## 性能调优

### 1. 内存配置
```java
// 根据可用内存调整，建议不超过堆内存的70%
.memoryLimit(Runtime.getRuntime().maxMemory() * 7 / 10)
```

### 2. 并行度
```java
// 对于CPU密集型，使用CPU核心数
// 对于IO密集型，可适当增加
.parallelism(Runtime.getRuntime().availableProcessors())
```

### 3. 合并因子
```java
// 合并因子越大，IO次数越少，但内存占用越高
.mergeFactor(32)  // 大内存环境
.mergeFactor(8)   // 小内存环境
```

### 4. 多磁盘
```java
// 使用多个物理磁盘提升IO性能
.addSpillDirectory(Path.of("/ssd1/spill"))
.addSpillDirectory(Path.of("/ssd2/spill"))
.addSpillDirectory(Path.of("/hdd1/spill"))
```

## 异常处理

ExternalSorter会在以下情况自动清理临时文件：
- 正常完成迭代
- 显式调用close()
- 发生异常时

建议使用try-with-resources确保资源释放：

```java
try (ExternalSorter sorter = new ExternalSorter(config)) {
    // 执行排序...
} // 自动清理
```

## 线程安全

- ExternalSorter实例本身是线程安全的
- 同一时间只允许一个排序任务执行
- 返回的Iterator不是线程安全的，需要在单线程中使用

## 依赖

- Java 11+
- Apache Parquet 1.13.x
- Apache Avro 1.11.x
- Apache Hadoop 3.3.x
- SLF4J 2.x
- Logback 1.4.x

## 许可证

Apache License 2.0
