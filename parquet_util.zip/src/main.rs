//! Parquet合并工具命令行入口
//!
//! 使用DataFusion异步接口将多个小parquet文件合并成一个大文件

use std::path::PathBuf;

use anyhow::Result;
use clap::{Parser, ValueEnum};
use datafusion::parquet::basic::Compression;
use parquet_util::{MergeOptions, ParquetMerger};
use tracing::{info, Level};
use tracing_subscriber::FmtSubscriber;

/// 压缩算法选项
#[derive(Debug, Clone, Copy, ValueEnum)]
enum CompressionType {
    /// 不压缩
    None,
    /// Snappy压缩（默认，速度快）
    Snappy,
    /// Gzip压缩（压缩率高）
    Gzip,
    /// LZ4压缩
    Lz4,
    /// Zstd压缩（推荐，平衡压缩率和速度）
    Zstd,
    /// Brotli压缩
    Brotli,
}

impl From<CompressionType> for Compression {
    fn from(ct: CompressionType) -> Self {
        match ct {
            CompressionType::None => Compression::UNCOMPRESSED,
            CompressionType::Snappy => Compression::SNAPPY,
            CompressionType::Gzip => Compression::GZIP(Default::default()),
            CompressionType::Lz4 => Compression::LZ4,
            CompressionType::Zstd => Compression::ZSTD(Default::default()),
            CompressionType::Brotli => Compression::BROTLI(Default::default()),
        }
    }
}

/// Parquet文件合并工具（基于DataFusion异步接口）
///
/// 将多个小parquet文件合并成一个大文件
#[derive(Parser, Debug)]
#[command(author, version, about, long_about = None)]
struct Args {
    /// 输入路径（目录或glob模式）
    #[arg(short, long)]
    input: String,

    /// 输出文件路径
    #[arg(short, long)]
    output: PathBuf,

    /// 使用glob模式匹配文件（如 "data/**/*.parquet"）
    #[arg(short, long, default_value = "false")]
    glob: bool,

    /// 递归搜索子目录
    #[arg(short, long, default_value = "false")]
    recursive: bool,

    /// 压缩算法
    #[arg(short, long, value_enum, default_value = "snappy")]
    compression: CompressionType,

    /// 批次大小（每批读取的行数）
    #[arg(long, default_value = "8192")]
    batch_size: usize,

    /// 行组大小（每个行组的最大行数）
    #[arg(long, default_value = "1048576")]
    row_group_size: usize,

    /// 并行度（默认为CPU核心数）
    #[arg(long)]
    parallelism: Option<usize>,

    /// 跳过schema验证
    #[arg(long, default_value = "false")]
    skip_schema_validation: bool,

    /// 静默模式（不显示进度条）
    #[arg(short, long, default_value = "false")]
    quiet: bool,

    /// 详细输出
    #[arg(short, long, default_value = "false")]
    verbose: bool,
}

#[tokio::main]
async fn main() -> Result<()> {
    let args = Args::parse();

    // 初始化日志
    let level = if args.verbose {
        Level::DEBUG
    } else if args.quiet {
        Level::WARN
    } else {
        Level::INFO
    };

    let subscriber = FmtSubscriber::builder()
        .with_max_level(level)
        .with_target(false)
        .finish();
    tracing::subscriber::set_global_default(subscriber)?;

    // 配置合并选项
    let mut options = MergeOptions::new()
        .with_batch_size(args.batch_size)
        .with_compression(args.compression.into())
        .with_row_group_size(args.row_group_size)
        .with_recursive(args.recursive)
        .with_progress(!args.quiet)
        .with_validate_schema(!args.skip_schema_validation);

    if let Some(parallelism) = args.parallelism {
        options = options.with_parallelism(parallelism);
    }

    let merger = ParquetMerger::with_options(options);

    // 执行异步合并
    let stats = if args.glob {
        info!("Using glob pattern: {}", args.input);
        merger.merge_glob_async(&args.input, &args.output).await?
    } else {
        info!("Using directory: {}", args.input);
        merger.merge_dir_async(&args.input, &args.output).await?
    };

    // 输出统计信息
    println!("\n✅ 合并完成！（使用DataFusion异步接口）");
    println!("   处理文件数: {}", stats.files_processed);
    println!("   总行数: {}", stats.total_rows);
    println!("   行组数: {}", stats.row_groups_written);
    println!(
        "   输出文件大小: {} bytes ({:.2} MB)",
        stats.output_size_bytes,
        stats.output_size_bytes as f64 / 1024.0 / 1024.0
    );
    println!("   输出文件: {:?}", args.output);

    Ok(())
}
