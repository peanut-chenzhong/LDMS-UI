//! Parquet文件合并模块
//!
//! 使用DataFusion异步接口将多个小parquet文件合并成一个大文件

use std::path::{Path, PathBuf};
use std::sync::Arc;

use arrow::datatypes::Schema;
use datafusion::dataframe::DataFrameWriteOptions;
use datafusion::datasource::file_format::parquet::ParquetFormat;
use datafusion::datasource::listing::{ListingOptions, ListingTable, ListingTableConfig, ListingTableUrl};
use datafusion::execution::context::SessionContext;
use datafusion::parquet::basic::Compression;
use datafusion::parquet::file::reader::FileReader;
use datafusion::config::TableParquetOptions;
use datafusion::prelude::*;
use glob::glob;
use indicatif::{ProgressBar, ProgressStyle};
use tracing::{debug, info, warn};
use walkdir::WalkDir;

use crate::error::{ParquetUtilError, Result};

/// 合并选项配置
#[derive(Debug, Clone)]
pub struct MergeOptions {
    /// 批次大小（每批读取的行数）
    pub batch_size: usize,
    /// 压缩算法
    pub compression: Compression,
    /// 行组大小（每个行组的最大行数）
    pub row_group_size: usize,
    /// 是否递归搜索子目录
    pub recursive: bool,
    /// 是否显示进度条
    pub show_progress: bool,
    /// 是否验证schema一致性
    pub validate_schema: bool,
    /// 并行度
    pub parallelism: usize,
}

impl Default for MergeOptions {
    fn default() -> Self {
        Self {
            batch_size: 8192,
            compression: Compression::SNAPPY,
            row_group_size: 1024 * 1024, // 1M rows per row group
            recursive: false,
            show_progress: true,
            validate_schema: true,
            parallelism: num_cpus::get(),
        }
    }
}

impl MergeOptions {
    /// 创建新的合并选项
    pub fn new() -> Self {
        Self::default()
    }

    /// 设置批次大小
    pub fn with_batch_size(mut self, batch_size: usize) -> Self {
        self.batch_size = batch_size;
        self
    }

    /// 设置压缩算法
    pub fn with_compression(mut self, compression: Compression) -> Self {
        self.compression = compression;
        self
    }

    /// 设置行组大小
    pub fn with_row_group_size(mut self, row_group_size: usize) -> Self {
        self.row_group_size = row_group_size;
        self
    }

    /// 设置是否递归搜索
    pub fn with_recursive(mut self, recursive: bool) -> Self {
        self.recursive = recursive;
        self
    }

    /// 设置是否显示进度条
    pub fn with_progress(mut self, show_progress: bool) -> Self {
        self.show_progress = show_progress;
        self
    }

    /// 设置是否验证schema
    pub fn with_validate_schema(mut self, validate_schema: bool) -> Self {
        self.validate_schema = validate_schema;
        self
    }

    /// 设置并行度
    pub fn with_parallelism(mut self, parallelism: usize) -> Self {
        self.parallelism = parallelism;
        self
    }

    /// 将压缩类型转换为字符串（用于TableParquetOptions）
    fn compression_to_string(&self) -> String {
        match self.compression {
            Compression::UNCOMPRESSED => "uncompressed".to_string(),
            Compression::SNAPPY => "snappy".to_string(),
            Compression::GZIP(level) => format!("gzip({})", level.compression_level()),
            Compression::LZO => "lzo".to_string(),
            Compression::BROTLI(level) => format!("brotli({})", level.compression_level()),
            Compression::LZ4 => "lz4".to_string(),
            Compression::ZSTD(level) => format!("zstd({})", level.compression_level()),
            Compression::LZ4_RAW => "lz4_raw".to_string(),
        }
    }
}

/// Parquet文件合并器（使用DataFusion异步接口）
pub struct ParquetMerger {
    options: MergeOptions,
}

impl ParquetMerger {
    /// 使用默认选项创建合并器
    pub fn new() -> Self {
        Self {
            options: MergeOptions::default(),
        }
    }

    /// 使用自定义选项创建合并器
    pub fn with_options(options: MergeOptions) -> Self {
        Self { options }
    }

    /// 从目录中收集所有parquet文件
    pub fn collect_files_from_dir<P: AsRef<Path>>(&self, dir: P) -> Result<Vec<PathBuf>> {
        let dir = dir.as_ref();
        let mut files = Vec::new();

        if self.options.recursive {
            for entry in WalkDir::new(dir).follow_links(true) {
                let entry = entry?;
                if entry.file_type().is_file() {
                    let path = entry.path();
                    if Self::is_parquet_file(path) {
                        files.push(path.to_path_buf());
                    }
                }
            }
        } else {
            for entry in std::fs::read_dir(dir)? {
                let entry = entry?;
                let path = entry.path();
                if path.is_file() && Self::is_parquet_file(&path) {
                    files.push(path);
                }
            }
        }

        // 按文件名排序，保证结果一致性
        files.sort();

        if files.is_empty() {
            return Err(ParquetUtilError::NoInputFiles);
        }

        info!("Found {} parquet files", files.len());
        Ok(files)
    }

    /// 使用glob模式匹配收集文件
    pub fn collect_files_from_glob(&self, pattern: &str) -> Result<Vec<PathBuf>> {
        let mut files = Vec::new();

        for entry in glob(pattern)? {
            match entry {
                Ok(path) => {
                    if path.is_file() && Self::is_parquet_file(&path) {
                        files.push(path);
                    }
                }
                Err(e) => {
                    warn!("Error matching pattern: {}", e);
                }
            }
        }

        files.sort();

        if files.is_empty() {
            return Err(ParquetUtilError::NoInputFiles);
        }

        info!("Found {} parquet files matching pattern", files.len());
        Ok(files)
    }

    /// 检查文件是否为parquet文件
    fn is_parquet_file(path: &Path) -> bool {
        path.extension()
            .map(|ext| ext.eq_ignore_ascii_case("parquet"))
            .unwrap_or(false)
    }

    /// 将路径转换为file:// URL格式
    /// 
    /// Windows路径需要特殊处理：
    /// - 移除 \\?\ 前缀
    /// - 将反斜杠转换为正斜杠
    /// - 添加 file:/// 前缀
    fn path_to_url(path: &Path, is_dir: bool) -> Result<String> {
        let path_str = path.to_string_lossy().to_string();
        
        // 处理Windows的 \\?\ 前缀
        let path_str = if path_str.starts_with(r"\\?\") {
            path_str[4..].to_string()
        } else {
            path_str
        };
        
        // 转换反斜杠为正斜杠
        let path_str = path_str.replace('\\', "/");
        
        // 构建URL
        let url = if cfg!(windows) {
            if is_dir {
                format!("file:///{}/", path_str)
            } else {
                format!("file:///{}", path_str)
            }
        } else {
            if is_dir {
                format!("file://{}/", path_str)
            } else {
                format!("file://{}", path_str)
            }
        };
        
        Ok(url)
    }

    /// 使用DataFusion异步读取parquet文件的schema
    pub async fn read_schema_async<P: AsRef<Path>>(path: P) -> Result<Arc<Schema>> {
        let ctx = SessionContext::new();
        let abs_path = std::fs::canonicalize(path.as_ref())?;
        let path_url = Self::path_to_url(&abs_path, false)?;
        
        let df = ctx.read_parquet(&path_url, ParquetReadOptions::default()).await?;
        Ok(df.schema().inner().clone())
    }

    /// 验证所有文件的schema是否一致
    pub async fn validate_schemas_async(&self, files: &[PathBuf]) -> Result<Arc<Schema>> {
        if files.is_empty() {
            return Err(ParquetUtilError::NoInputFiles);
        }

        let first_schema = Self::read_schema_async(&files[0]).await?;
        debug!("Reference schema from {:?}: {:?}", files[0], first_schema);

        if self.options.validate_schema {
            for file in files.iter().skip(1) {
                let schema = Self::read_schema_async(file).await?;
                if schema != first_schema {
                    return Err(ParquetUtilError::SchemaMismatch {
                        expected: format!("{:?}", first_schema),
                        found: format!("{:?}", schema),
                    });
                }
            }
            info!("All {} files have consistent schema", files.len());
        }

        Ok(first_schema)
    }

    /// 使用DataFusion异步合并多个parquet文件到一个输出文件
    ///
    /// # Arguments
    /// * `input_files` - 输入文件路径列表
    /// * `output_path` - 输出文件路径
    ///
    /// # Returns
    /// * `Ok(MergeStats)` - 合并统计信息
    pub async fn merge_async<P: AsRef<Path>>(
        &self,
        input_files: &[PathBuf],
        output_path: P,
    ) -> Result<MergeStats> {
        let output_path = output_path.as_ref();

        if input_files.is_empty() {
            return Err(ParquetUtilError::NoInputFiles);
        }

        info!(
            "Starting async merge of {} files to {:?}",
            input_files.len(),
            output_path
        );

        // 设置进度条
        let progress = if self.options.show_progress {
            let pb = ProgressBar::new(input_files.len() as u64);
            pb.set_style(
                ProgressStyle::default_bar()
                    .template("{spinner:.green} [{elapsed_precise}] [{bar:40.cyan/blue}] {pos}/{len} files ({eta})")
                    .unwrap()
                    .progress_chars("#>-"),
            );
            Some(pb)
        } else {
            None
        };

        // 创建DataFusion会话上下文
        let config = SessionConfig::new()
            .with_batch_size(self.options.batch_size)
            .with_target_partitions(self.options.parallelism);
        let ctx = SessionContext::new_with_config(config);

        // 获取输入目录的绝对路径
        let first_file = &input_files[0];
        let input_dir = first_file.parent().unwrap_or(Path::new("."));
        let abs_input_dir = std::fs::canonicalize(input_dir)?;
        
        // 构建listing table URL (处理Windows路径)
        let table_path = Self::path_to_url(&abs_input_dir, true)?;

        debug!("Table path: {}", table_path);

        // 配置parquet读取选项
        let file_format = ParquetFormat::default()
            .with_enable_pruning(true);
        
        let listing_options = ListingOptions::new(Arc::new(file_format))
            .with_file_extension(".parquet")
            .with_collect_stat(true);

        let table_url = ListingTableUrl::parse(&table_path)?;
        
        // 推断schema
        let schema = listing_options.infer_schema(&ctx.state(), &table_url).await?;
        
        let config = ListingTableConfig::new(table_url)
            .with_listing_options(listing_options)
            .with_schema(schema);

        let listing_table = ListingTable::try_new(config)?;

        // 注册表
        ctx.register_table("input_parquet", Arc::new(listing_table))?;

        // 查询所有数据
        let df = ctx.sql("SELECT * FROM input_parquet").await?;
        
        // 获取总行数（用于统计）
        let count_df = ctx.sql("SELECT COUNT(*) as cnt FROM input_parquet").await?;
        let count_batches = count_df.collect().await?;
        let total_rows = if !count_batches.is_empty() && count_batches[0].num_rows() > 0 {
            let array = count_batches[0].column(0);
            arrow::array::cast::as_primitive_array::<arrow::datatypes::Int64Type>(array).value(0) as usize
        } else {
            0
        };

        if let Some(ref pb) = progress {
            pb.set_position(input_files.len() as u64 / 2);
        }

        // 配置parquet写入选项（使用TableParquetOptions）
        let mut parquet_options = TableParquetOptions::default();
        parquet_options.global.compression = Some(self.options.compression_to_string());
        parquet_options.global.max_row_group_size = self.options.row_group_size;

        // 获取输出路径的绝对路径
        let abs_output_path = if output_path.is_absolute() {
            output_path.to_path_buf()
        } else {
            std::env::current_dir()?.join(output_path)
        };

        let output_path_str = Self::path_to_url(&abs_output_path, false)?;

        debug!("Output path: {}", output_path_str);

        // 异步写入parquet文件
        let write_options = DataFrameWriteOptions::new()
            .with_single_file_output(true);  // 确保输出单个文件

        df.write_parquet(
            &output_path_str,
            write_options,
            Some(parquet_options),
        )
        .await?;

        if let Some(pb) = progress {
            pb.finish_with_message("Merge completed!");
        }

        // 收集统计信息
        let output_size_bytes = std::fs::metadata(&abs_output_path)?.len();
        
        // 读取输出文件获取行组数
        let output_file = std::fs::File::open(&abs_output_path)?;
        let reader = datafusion::parquet::file::reader::SerializedFileReader::new(output_file)?;
        let row_groups_written = reader.metadata().num_row_groups();

        let stats = MergeStats {
            files_processed: input_files.len(),
            total_rows,
            row_groups_written,
            output_size_bytes,
        };

        info!(
            "Async merge completed: {} files, {} rows, {} row groups, {} bytes",
            stats.files_processed, stats.total_rows, stats.row_groups_written, stats.output_size_bytes
        );

        Ok(stats)
    }

    /// 异步合并目录中的所有parquet文件
    pub async fn merge_dir_async<P: AsRef<Path>, Q: AsRef<Path>>(
        &self,
        input_dir: P,
        output_path: Q,
    ) -> Result<MergeStats> {
        let files = self.collect_files_from_dir(input_dir)?;
        self.merge_async(&files, output_path).await
    }

    /// 使用glob模式异步合并文件
    pub async fn merge_glob_async<P: AsRef<Path>>(
        &self,
        pattern: &str,
        output_path: P,
    ) -> Result<MergeStats> {
        let files = self.collect_files_from_glob(pattern)?;
        self.merge_async(&files, output_path).await
    }

    // ========== 同步包装方法（向后兼容）==========
    
    /// 读取parquet文件的schema（同步包装）
    pub fn read_schema<P: AsRef<Path>>(path: P) -> Result<Arc<Schema>> {
        let rt = tokio::runtime::Runtime::new()?;
        rt.block_on(Self::read_schema_async(path))
    }

    /// 合并多个parquet文件（同步包装）
    pub fn merge<P: AsRef<Path>>(&self, input_files: &[PathBuf], output_path: P) -> Result<MergeStats> {
        let rt = tokio::runtime::Runtime::new()?;
        rt.block_on(self.merge_async(input_files, output_path))
    }

    /// 合并目录中的所有parquet文件（同步包装）
    pub fn merge_dir<P: AsRef<Path>, Q: AsRef<Path>>(&self, input_dir: P, output_path: Q) -> Result<MergeStats> {
        let rt = tokio::runtime::Runtime::new()?;
        rt.block_on(self.merge_dir_async(input_dir, output_path))
    }

    /// 使用glob模式合并文件（同步包装）
    pub fn merge_glob<P: AsRef<Path>>(&self, pattern: &str, output_path: P) -> Result<MergeStats> {
        let rt = tokio::runtime::Runtime::new()?;
        rt.block_on(self.merge_glob_async(pattern, output_path))
    }
}

impl Default for ParquetMerger {
    fn default() -> Self {
        Self::new()
    }
}

/// 合并操作统计信息
#[derive(Debug, Default, Clone)]
pub struct MergeStats {
    /// 处理的文件数
    pub files_processed: usize,
    /// 总行数
    pub total_rows: usize,
    /// 写入的行组数
    pub row_groups_written: usize,
    /// 输出文件大小（字节）
    pub output_size_bytes: u64,
}

impl std::fmt::Display for MergeStats {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(
            f,
            "Files: {}, Rows: {}, Row Groups: {}, Output Size: {} bytes",
            self.files_processed, self.total_rows, self.row_groups_written, self.output_size_bytes
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_merge_options_default() {
        let options = MergeOptions::default();
        assert_eq!(options.batch_size, 8192);
        assert!(options.show_progress);
        assert!(options.validate_schema);
    }

    #[test]
    fn test_merge_options_builder() {
        let options = MergeOptions::new()
            .with_batch_size(1024)
            .with_compression(Compression::ZSTD(Default::default()))
            .with_recursive(true)
            .with_progress(false)
            .with_parallelism(4);

        assert_eq!(options.batch_size, 1024);
        assert!(options.recursive);
        assert!(!options.show_progress);
        assert_eq!(options.parallelism, 4);
    }

    #[test]
    fn test_is_parquet_file() {
        assert!(ParquetMerger::is_parquet_file(Path::new("test.parquet")));
        assert!(ParquetMerger::is_parquet_file(Path::new("test.PARQUET")));
        assert!(!ParquetMerger::is_parquet_file(Path::new("test.csv")));
        assert!(!ParquetMerger::is_parquet_file(Path::new("test")));
    }
}
