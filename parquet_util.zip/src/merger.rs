//! Parquet文件合并模块
//!
//! 提供将多个小parquet文件合并成一个大文件的功能

use std::fs::File;
use std::path::{Path, PathBuf};
use std::sync::Arc;

use arrow::datatypes::Schema;
use glob::glob;
use indicatif::{ProgressBar, ProgressStyle};
use parquet::arrow::arrow_reader::ParquetRecordBatchReaderBuilder;
use parquet::arrow::ArrowWriter;
use parquet::basic::Compression;
use parquet::file::properties::WriterProperties;
use tracing::{debug, info, warn};
use walkdir::WalkDir;

use crate::error::{ParquetUtilError, Result};

/// 合并选项配置
#[derive(Debug, Clone)]
pub struct MergeOptions {
    /// 批次大小（每批读取的行数）
    pub batch_size: usize,
    /// 压缩算法
    pub compression: Compression,
    /// 行组大小（每个行组的最大行数）
    pub row_group_size: usize,
    /// 是否递归搜索子目录
    pub recursive: bool,
    /// 是否显示进度条
    pub show_progress: bool,
    /// 是否验证schema一致性
    pub validate_schema: bool,
}

impl Default for MergeOptions {
    fn default() -> Self {
        Self {
            batch_size: 8192,
            compression: Compression::SNAPPY,
            row_group_size: 1024 * 1024, // 1M rows per row group
            recursive: false,
            show_progress: true,
            validate_schema: true,
        }
    }
}

impl MergeOptions {
    /// 创建新的合并选项
    pub fn new() -> Self {
        Self::default()
    }

    /// 设置批次大小
    pub fn with_batch_size(mut self, batch_size: usize) -> Self {
        self.batch_size = batch_size;
        self
    }

    /// 设置压缩算法
    pub fn with_compression(mut self, compression: Compression) -> Self {
        self.compression = compression;
        self
    }

    /// 设置行组大小
    pub fn with_row_group_size(mut self, row_group_size: usize) -> Self {
        self.row_group_size = row_group_size;
        self
    }

    /// 设置是否递归搜索
    pub fn with_recursive(mut self, recursive: bool) -> Self {
        self.recursive = recursive;
        self
    }

    /// 设置是否显示进度条
    pub fn with_progress(mut self, show_progress: bool) -> Self {
        self.show_progress = show_progress;
        self
    }

    /// 设置是否验证schema
    pub fn with_validate_schema(mut self, validate_schema: bool) -> Self {
        self.validate_schema = validate_schema;
        self
    }
}

/// Parquet文件合并器
pub struct ParquetMerger {
    options: MergeOptions,
}

impl ParquetMerger {
    /// 使用默认选项创建合并器
    pub fn new() -> Self {
        Self {
            options: MergeOptions::default(),
        }
    }

    /// 使用自定义选项创建合并器
    pub fn with_options(options: MergeOptions) -> Self {
        Self { options }
    }

    /// 从目录中收集所有parquet文件
    pub fn collect_files_from_dir<P: AsRef<Path>>(&self, dir: P) -> Result<Vec<PathBuf>> {
        let dir = dir.as_ref();
        let mut files = Vec::new();

        if self.options.recursive {
            for entry in WalkDir::new(dir).follow_links(true) {
                let entry = entry?;
                if entry.file_type().is_file() {
                    let path = entry.path();
                    if Self::is_parquet_file(path) {
                        files.push(path.to_path_buf());
                    }
                }
            }
        } else {
            for entry in std::fs::read_dir(dir)? {
                let entry = entry?;
                let path = entry.path();
                if path.is_file() && Self::is_parquet_file(&path) {
                    files.push(path);
                }
            }
        }

        // 按文件名排序，保证结果一致性
        files.sort();

        if files.is_empty() {
            return Err(ParquetUtilError::NoInputFiles);
        }

        info!("Found {} parquet files", files.len());
        Ok(files)
    }

    /// 使用glob模式匹配收集文件
    pub fn collect_files_from_glob(&self, pattern: &str) -> Result<Vec<PathBuf>> {
        let mut files = Vec::new();

        for entry in glob(pattern)? {
            match entry {
                Ok(path) => {
                    if path.is_file() && Self::is_parquet_file(&path) {
                        files.push(path);
                    }
                }
                Err(e) => {
                    warn!("Error matching pattern: {}", e);
                }
            }
        }

        files.sort();

        if files.is_empty() {
            return Err(ParquetUtilError::NoInputFiles);
        }

        info!("Found {} parquet files matching pattern", files.len());
        Ok(files)
    }

    /// 检查文件是否为parquet文件
    fn is_parquet_file(path: &Path) -> bool {
        path.extension()
            .map(|ext| ext.eq_ignore_ascii_case("parquet"))
            .unwrap_or(false)
    }

    /// 读取parquet文件的schema
    pub fn read_schema<P: AsRef<Path>>(path: P) -> Result<Arc<Schema>> {
        let file = File::open(path)?;
        let builder = ParquetRecordBatchReaderBuilder::try_new(file)?;
        Ok(builder.schema().clone())
    }

    /// 验证所有文件的schema是否一致
    pub fn validate_schemas(&self, files: &[PathBuf]) -> Result<Arc<Schema>> {
        if files.is_empty() {
            return Err(ParquetUtilError::NoInputFiles);
        }

        let first_schema = Self::read_schema(&files[0])?;
        debug!("Reference schema from {:?}: {:?}", files[0], first_schema);

        if self.options.validate_schema {
            for file in files.iter().skip(1) {
                let schema = Self::read_schema(file)?;
                if schema != first_schema {
                    return Err(ParquetUtilError::SchemaMismatch {
                        expected: format!("{:?}", first_schema),
                        found: format!("{:?}", schema),
                    });
                }
            }
            info!("All {} files have consistent schema", files.len());
        }

        Ok(first_schema)
    }

    /// 合并多个parquet文件到一个输出文件
    ///
    /// # Arguments
    /// * `input_files` - 输入文件路径列表
    /// * `output_path` - 输出文件路径
    ///
    /// # Returns
    /// * `Ok(MergeStats)` - 合并统计信息
    pub fn merge<P: AsRef<Path>>(&self, input_files: &[PathBuf], output_path: P) -> Result<MergeStats> {
        let output_path = output_path.as_ref();

        if input_files.is_empty() {
            return Err(ParquetUtilError::NoInputFiles);
        }

        info!("Starting merge of {} files to {:?}", input_files.len(), output_path);

        // 验证schema
        let schema = self.validate_schemas(input_files)?;

        // 配置writer属性
        let props = WriterProperties::builder()
            .set_compression(self.options.compression)
            .set_max_row_group_size(self.options.row_group_size)
            .build();

        // 创建输出文件
        let output_file = File::create(output_path)?;
        let mut writer = ArrowWriter::try_new(output_file, schema.clone(), Some(props))?;

        // 设置进度条
        let progress = if self.options.show_progress {
            let pb = ProgressBar::new(input_files.len() as u64);
            pb.set_style(
                ProgressStyle::default_bar()
                    .template("{spinner:.green} [{elapsed_precise}] [{bar:40.cyan/blue}] {pos}/{len} files ({eta})")
                    .unwrap()
                    .progress_chars("#>-"),
            );
            Some(pb)
        } else {
            None
        };

        let mut stats = MergeStats::default();

        // 逐个处理输入文件
        for input_file in input_files {
            debug!("Processing file: {:?}", input_file);
            
            let file = File::open(input_file)?;
            let builder = ParquetRecordBatchReaderBuilder::try_new(file)?
                .with_batch_size(self.options.batch_size);
            
            let reader = builder.build()?;

            for batch_result in reader {
                let batch = batch_result?;
                stats.total_rows += batch.num_rows();
                writer.write(&batch)?;
            }

            stats.files_processed += 1;

            if let Some(ref pb) = progress {
                pb.inc(1);
            }
        }

        // 关闭writer并获取元数据
        let metadata = writer.close()?;
        stats.output_size_bytes = std::fs::metadata(output_path)?.len();
        stats.row_groups_written = metadata.row_groups.len();

        if let Some(pb) = progress {
            pb.finish_with_message("Merge completed!");
        }

        info!(
            "Merge completed: {} files, {} rows, {} row groups, {} bytes",
            stats.files_processed, stats.total_rows, stats.row_groups_written, stats.output_size_bytes
        );

        Ok(stats)
    }

    /// 合并目录中的所有parquet文件
    pub fn merge_dir<P: AsRef<Path>, Q: AsRef<Path>>(&self, input_dir: P, output_path: Q) -> Result<MergeStats> {
        let files = self.collect_files_from_dir(input_dir)?;
        self.merge(&files, output_path)
    }

    /// 使用glob模式合并文件
    pub fn merge_glob<P: AsRef<Path>>(&self, pattern: &str, output_path: P) -> Result<MergeStats> {
        let files = self.collect_files_from_glob(pattern)?;
        self.merge(&files, output_path)
    }
}

impl Default for ParquetMerger {
    fn default() -> Self {
        Self::new()
    }
}

/// 合并操作统计信息
#[derive(Debug, Default, Clone)]
pub struct MergeStats {
    /// 处理的文件数
    pub files_processed: usize,
    /// 总行数
    pub total_rows: usize,
    /// 写入的行组数
    pub row_groups_written: usize,
    /// 输出文件大小（字节）
    pub output_size_bytes: u64,
}

impl std::fmt::Display for MergeStats {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(
            f,
            "Files: {}, Rows: {}, Row Groups: {}, Output Size: {} bytes",
            self.files_processed, self.total_rows, self.row_groups_written, self.output_size_bytes
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_merge_options_default() {
        let options = MergeOptions::default();
        assert_eq!(options.batch_size, 8192);
        assert!(options.show_progress);
        assert!(options.validate_schema);
    }

    #[test]
    fn test_merge_options_builder() {
        let options = MergeOptions::new()
            .with_batch_size(1024)
            .with_compression(Compression::ZSTD(Default::default()))
            .with_recursive(true)
            .with_progress(false);

        assert_eq!(options.batch_size, 1024);
        assert!(options.recursive);
        assert!(!options.show_progress);
    }

    #[test]
    fn test_is_parquet_file() {
        assert!(ParquetMerger::is_parquet_file(Path::new("test.parquet")));
        assert!(ParquetMerger::is_parquet_file(Path::new("test.PARQUET")));
        assert!(!ParquetMerger::is_parquet_file(Path::new("test.csv")));
        assert!(!ParquetMerger::is_parquet_file(Path::new("test")));
    }
}
