//! 错误处理模块

use thiserror::Error;

/// Parquet工具库的错误类型
#[derive(Error, Debug)]
pub enum ParquetUtilError {
    /// IO错误
    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),

    /// Parquet错误
    #[error("Parquet error: {0}")]
    Parquet(#[from] parquet::errors::ParquetError),

    /// Arrow错误
    #[error("Arrow error: {0}")]
    Arrow(#[from] arrow::error::ArrowError),

    /// Schema不匹配错误
    #[error("Schema mismatch: expected {expected}, found {found}")]
    SchemaMismatch { expected: String, found: String },

    /// 没有找到输入文件
    #[error("No input files found")]
    NoInputFiles,

    /// 文件模式匹配错误
    #[error("Glob pattern error: {0}")]
    GlobPattern(#[from] glob::PatternError),

    /// 文件遍历错误
    #[error("Walkdir error: {0}")]
    WalkDir(#[from] walkdir::Error),

    /// 其他错误
    #[error("{0}")]
    Other(String),
}

/// Result类型别名
pub type Result<T> = std::result::Result<T, ParquetUtilError>;
