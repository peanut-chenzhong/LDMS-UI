//! Parquet Utility Library
//!
//! 提供读取多个小parquet文件并合并写入一个大parquet文件的功能

mod error;
mod merger;

pub use error::ParquetUtilError;
pub use merger::{MergeOptions, ParquetMerger};
