//! 测试parquet文件合并功能的示例（使用DataFusion异步接口）
//!
//! 运行: cargo run --example test_merge
//! 保留测试文件: cargo run --example test_merge -- --keep

use std::env;
use std::fs;
use std::sync::Arc;

use arrow::array::{Int32Array, StringArray};
use arrow::datatypes::{DataType, Field, Schema};
use arrow::record_batch::RecordBatch;
use parquet::arrow::ArrowWriter;
use parquet::file::properties::WriterProperties;

use parquet_util::{MergeOptions, ParquetMerger};

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    let args: Vec<String> = env::args().collect();
    let keep_files = args.iter().any(|a| a == "--keep" || a == "--keep-files");

    // 创建测试目录
    let test_dir = "test_data";
    let output_file = "test_output.parquet";

    // 清理旧数据
    let _ = fs::remove_dir_all(test_dir);
    let _ = fs::remove_file(output_file);
    fs::create_dir_all(test_dir)?;

    println!("📁 创建测试目录: {}", test_dir);

    // 定义schema
    let schema = Arc::new(Schema::new(vec![
        Field::new("id", DataType::Int32, false),
        Field::new("name", DataType::Utf8, false),
        Field::new("value", DataType::Int32, false),
    ]));

    // 创建多个小parquet文件
    let num_files = 5;
    let rows_per_file = 100;

    for file_idx in 0..num_files {
        let file_path = format!("{}/data_{:03}.parquet", test_dir, file_idx);
        let file = fs::File::create(&file_path)?;

        let props = WriterProperties::builder().build();
        let mut writer = ArrowWriter::try_new(file, schema.clone(), Some(props))?;

        // 创建数据
        let start_id = file_idx * rows_per_file;
        let ids: Vec<i32> = (start_id..(start_id + rows_per_file))
            .map(|x| x as i32)
            .collect();
        let names: Vec<String> = ids.iter().map(|id| format!("item_{}", id)).collect();
        let values: Vec<i32> = ids.iter().map(|id| id * 10).collect();

        let batch = RecordBatch::try_new(
            schema.clone(),
            vec![
                Arc::new(Int32Array::from(ids)),
                Arc::new(StringArray::from(names)),
                Arc::new(Int32Array::from(values)),
            ],
        )?;

        writer.write(&batch)?;
        writer.close()?;

        println!("  ✅ 创建文件: {} ({} 行)", file_path, rows_per_file);
    }

    println!(
        "\n📊 共创建 {} 个parquet文件，每个文件 {} 行",
        num_files, rows_per_file
    );

    // 使用DataFusion异步接口合并文件
    println!("\n🔄 使用DataFusion异步接口合并文件...\n");

    let options = MergeOptions::new()
        .with_batch_size(1024)
        .with_progress(true)
        .with_parallelism(4);

    let merger = ParquetMerger::with_options(options);
    let stats = merger.merge_dir_async(test_dir, output_file).await?;

    println!("\n✅ 合并完成！");
    println!("   处理文件数: {}", stats.files_processed);
    println!("   总行数: {}", stats.total_rows);
    println!("   行组数: {}", stats.row_groups_written);
    println!(
        "   输出文件大小: {} bytes ({:.2} KB)",
        stats.output_size_bytes,
        stats.output_size_bytes as f64 / 1024.0
    );

    // 验证输出文件
    println!("\n🔍 验证输出文件...");

    let output_schema = ParquetMerger::read_schema_async(output_file).await?;
    println!("   Schema: {:?}", output_schema);

    // 清理测试数据
    if keep_files {
        println!("\n📂 测试文件已保留在:");
        println!("   输入目录: {}", test_dir);
        println!("   输出文件: {}", output_file);
    } else {
        println!("\n🧹 清理测试数据...");
        fs::remove_dir_all(test_dir)?;
        fs::remove_file(output_file)?;
        println!("   ✅ 清理完成");
    }

    println!("\n🎉 测试全部通过！");

    Ok(())
}
