# Parquet Util

一个基于**DataFusion异步接口**实现的高性能Parquet文件合并工具，可以将多个小parquet文件合并成一个大文件。

## 功能特性

- ✅ 使用DataFusion异步接口进行高效的并行处理
- ✅ 合并多个小parquet文件到一个大文件
- ✅ 支持多种压缩算法（Snappy、Gzip、Zstd、LZ4、Brotli）
- ✅ 支持目录扫描和glob模式匹配
- ✅ 支持递归搜索子目录
- ✅ 自动验证schema一致性
- ✅ 显示进度条
- ✅ 可配置批次大小、行组大小和并行度

## 技术栈

- **DataFusion**: Apache Arrow的SQL查询引擎，提供异步parquet读写能力
- **Arrow**: 内存中的列式数据格式
- **Parquet**: 高效的列式存储格式
- **Tokio**: 异步运行时

## 安装

### 从源码构建

```bash
# 克隆项目
cd parquet_util

# 构建release版本
cargo build --release

# 可执行文件位于 target/release/parquet-merge
```

## 使用方法

### 命令行工具

```bash
# 合并目录中的所有parquet文件
parquet-merge -i ./input_dir -o ./output.parquet

# 递归搜索子目录
parquet-merge -i ./input_dir -o ./output.parquet -r

# 使用glob模式匹配
parquet-merge -i "data/**/*.parquet" -o ./output.parquet -g

# 指定压缩算法（推荐zstd）
parquet-merge -i ./input_dir -o ./output.parquet -c zstd

# 自定义批次大小和行组大小
parquet-merge -i ./input_dir -o ./output.parquet --batch-size 4096 --row-group-size 500000

# 指定并行度
parquet-merge -i ./input_dir -o ./output.parquet --parallelism 8

# 静默模式（不显示进度条）
parquet-merge -i ./input_dir -o ./output.parquet -q

# 详细输出
parquet-merge -i ./input_dir -o ./output.parquet -v
```

### 完整参数说明

```
Usage: parquet-merge [OPTIONS] --input <INPUT> --output <OUTPUT>

Options:
  -i, --input <INPUT>                  输入路径（目录或glob模式）
  -o, --output <OUTPUT>                输出文件路径
  -g, --glob                           使用glob模式匹配文件
  -r, --recursive                      递归搜索子目录
  -c, --compression <COMPRESSION>      压缩算法 [default: snappy]
                                       [possible values: none, snappy, gzip, lz4, zstd, brotli]
      --batch-size <BATCH_SIZE>        批次大小 [default: 8192]
      --row-group-size <ROW_GROUP_SIZE> 行组大小 [default: 1048576]
      --parallelism <PARALLELISM>      并行度（默认为CPU核心数）
      --skip-schema-validation         跳过schema验证
  -q, --quiet                          静默模式
  -v, --verbose                        详细输出
  -h, --help                           显示帮助信息
  -V, --version                        显示版本信息
```

### 作为库使用（异步API）

```rust
use parquet_util::{MergeOptions, ParquetMerger};
use datafusion::parquet::basic::Compression;

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    // 使用默认选项异步合并目录中的所有parquet文件
    let merger = ParquetMerger::new();
    let stats = merger.merge_dir_async("./input_dir", "./output.parquet").await?;
    println!("合并完成: {}", stats);

    // 使用自定义选项
    let options = MergeOptions::new()
        .with_batch_size(4096)
        .with_compression(Compression::ZSTD(Default::default()))
        .with_recursive(true)
        .with_parallelism(8);

    let merger = ParquetMerger::with_options(options);
    let stats = merger.merge_dir_async("./input_dir", "./output.parquet").await?;

    // 使用glob模式
    let stats = merger.merge_glob_async("data/**/*.parquet", "./output.parquet").await?;

    // 手动指定文件列表
    let files = vec![
        "file1.parquet".into(),
        "file2.parquet".into(),
        "file3.parquet".into(),
    ];
    let stats = merger.merge_async(&files, "./output.parquet").await?;

    Ok(())
}
```

### 同步API（向后兼容）

```rust
use parquet_util::{MergeOptions, ParquetMerger};

fn main() -> anyhow::Result<()> {
    let merger = ParquetMerger::new();
    
    // 同步方法会内部创建tokio运行时
    let stats = merger.merge_dir("./input_dir", "./output.parquet")?;
    println!("合并完成: {}", stats);
    
    Ok(())
}
```

## 压缩算法选择建议

| 算法 | 压缩率 | 速度 | 适用场景 |
|------|--------|------|----------|
| none | 无 | 最快 | 临时文件，后续还需处理 |
| snappy | 低 | 快 | 通用场景（默认） |
| lz4 | 低-中 | 快 | 需要快速读写 |
| **zstd** | **高** | **中** | **推荐，平衡压缩率和速度** |
| gzip | 高 | 慢 | 需要高压缩率 |
| brotli | 最高 | 最慢 | 长期存储 |

## 性能优势

使用DataFusion异步接口的优势：

1. **并行处理**: 利用多核CPU并行读取和处理数据
2. **异步I/O**: 非阻塞的文件读写操作
3. **内存效率**: 流式处理，不需要将所有数据加载到内存
4. **查询优化**: DataFusion的查询优化器可以优化数据处理流程

## 注意事项

1. **Schema一致性**: 默认会验证所有输入文件的schema必须一致，可以使用 `--skip-schema-validation` 跳过
2. **内存使用**: 批次大小和并行度会影响内存使用，如果内存不足可以减小 `--batch-size` 或 `--parallelism`
3. **文件顺序**: 文件会按文件名排序后合并，保证结果一致性

## 许可证

MIT License
